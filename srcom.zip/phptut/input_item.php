<?php
 require "connector.php";
//inserting data

$item_no=$_POST['item_no'];
$item_name=$_POST['item_name'];
$cost=$_POST['cost'];
$order = "INSERT INTO item VALUES('$item_no','$item_name','$cost')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
