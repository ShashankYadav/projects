#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<stdlib.h>
#include<time.h>
time_t st,end;// to store starting and ending times
int stud,taps;//the argumnets from command line
int nbh[100];//the array which has taps and scrubbers
sem_t mut[100];// mutex for taps and scrubbers
int status[100][3];//tells the status of utensil for each student
int don[100],dctr=0;// don[] tells if the studennt has been assigned a tap and dctr is no of students who have finished
double ti[100];//finishing times for each student
void *func(void *arg)
{
	int stid=(int)(arg);
	int left=0,temp1,right,temp2;
	int tno=1,i=0;
	int chs=0;
	if(status[stid][2]==2)
		return;
	//printf("don[%d] = %d\n",stid,don[stid]);
	while(status[stid][2]!=2)//while the students work is not done tap is kept acquired
	{

	left=0;
	if(don[stid]==-1)
	{
		while(1)
		{
			while(tno%2!=0)
			{
				if((2*taps-2)!=0)
					tno=rand()%(2*taps-1);//random generation of tap number till an empty tap is obtained
				else 
					tno=0;
			}		
			sem_getvalue(&mut[tno],&left);//check if the tap is available
			don[stid]=tno;
			if(left==1)
			{
				break;
			}

		}
	}
	//	if(left==1)
	tno=don[stid];
	if(left==1)
		sem_wait(&mut[tno]);//tap is acquired

	//	while(status[stid][2]!=2)
	//	{
	for(i=0;i<3;i++)//in utensil code 0 = plate 1 = glass 2 = spoon
	{
		if(status[stid][i]==2)//the utensil has been washed
			continue;
		if(status[stid][i]==1)
		{
			if(i==0)
			{
				printf("student %d is washing %d\n",stid,i);
				status[stid][i]=2;
								sleep(5);
				break;
			}
			if(i==1)
			{
				printf("student %d is washing %d\n",stid,i);
				status[stid][i]=2;
								sleep(3);
				break;
			}
			if(i==2)
			{
				printf("student %d is washing %d\n",stid,i);
				status[stid][i]=2;
								sleep(1);
				break;
			}
		}
		if(status[stid][i]==0)
		{int done=0;
			if(tno-1<0)
			{
				sem_wait(&mut[tno+1]);//right scrubber is acquired
				done=1;
				chs=1;
			}
			if(tno+1>(2*taps-2) && done==0)
			{
				sem_wait(&mut[tno-1]);//left scrubber is acquired
				done=1;
				chs=-1;
			}
			if(done==0)
			{
				while(1)
				{
					sem_getvalue(&mut[tno-1],&left);
					sem_getvalue(&mut[tno+1],&right);
					if(left==1)
					{
						chs=-1;//left scrubber is acquired
						break;
					}
					else if(right==1)
					{
						chs=1;//right scrubber is acquired
						break;
					}
				}
				if(left==1)
					sem_wait(&mut[tno-1]);//acquiring the scrubber
				if(right==1)
					sem_wait(&mut[tno+1]);//acquiring the scrubber
			}
			if(i==0)
			{
				printf("student %d is scrubbing %d\n",stid,i);
				status[stid][i]=1;
				sleep(4);
				if(chs==-1)
					sem_post(&mut[tno-1]);//leaving the acquired scrubber
				if(chs==1)
					sem_post(&mut[tno+1]);//leaving the acquired scrubber
				break;
			}
			else if(i==1)
			{
				printf("student %d is scrubbing %d\n",stid,i);
				status[stid][i]=1;
				sleep(3);
				if(chs==-1)
					sem_post(&mut[tno-1]);//leaving the acquired scrubber
				if(chs==1)
					sem_post(&mut[tno+1]);//leaving the acquired scrubber
				break;
			}
			else if(i==2)
			{
				printf("student %d is scrubbing %d\n",stid,i);
				status[stid][i]=1;
				sleep(2);
				if(chs==-1)
					sem_post(&mut[tno-1]);//leaving the acquired scrubber
				if(chs==1)
					sem_post(&mut[tno+1]);//leaving the acquired scrubber
				break;
			}


		}
	}
	}
	if(status[stid][2]==2)
	{
		time(&end);
		printf("student %d finished at %lf\n",stid,difftime(end,st));//time difference is printed
		ti[stid]=difftime(end,st);//time diff stored in output array
		dctr++;
		don[tno]=-2;
		sem_post(&mut[tno]);//as work is finished tap is left
	}

}
int main(int argc, char *argv[])
{
	int i,j;
	time(&st);
	taps=atoi(argv[1]);
	stud=atoi(argv[2]);
//	taps=2;
//	stud=1;
	srand(time(0));
	pthread_t st[stud];
	for(i=0;i<=(2*taps-2);i++)
	{
		sem_init(&mut[i],0,1);//initializing the mutex
		nbh[i]=1;
		don[i]=-1;//no tap has been acquired
	}
//	while(1)
//	{
		for(i=0;i<stud;i++)
		{
			pthread_create(&st[i],NULL,func,(void *)i);
		}
		for(i=0;i<stud;i++)
		{
			pthread_join(st[i],NULL);
		}
//		if(dctr==stud)
//			break;
//	}
	printf("\n");
	for(i=0;i<stud;i++)
		printf("student %d finishes at %lf\n",i,ti[i]);//printing of time array

	return 0;
}
