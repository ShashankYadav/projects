<?php
 require "connector.php";
session_start(); 
// for the admin interface pages
 //remove second condition if interface is to be normal user one!
if(empty($_SESSION['user']) || $_SESSION['user']['grp'] !=1) 
{
// If they are not, we redirect them to the login page. 
 header("Location: login.php");    
  //print "not valid";
 // Remember that this die statement is absolutely critical.  Without it, 
// people can view your members-only content without logging in. 
die("Redirecting to login.php"); 
}

//inserting data

$dealer_id=$_POST['dealer_id'];
$dealname=$_POST['dealname'];
$phone=$_POST['phone'];
$deals_in=$_POST['deals_in'];
$order = "UPDATE dealer SET dealer_id='$dealer_id' , dealname='$dealname' , phone='$phone' , deals_in='$deals_in' where dealer_id='$dealer_id';";
 //declare in the order variables
$result = mysql_query($order); //order executes
if(!$result){
 $str="Unsuccessful";
}
 else{
$str="Successful";
}
$name=$_GET['name'];
header("Location:show.php?name=$name&str=$str&v=3");
?>
