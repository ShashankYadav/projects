#!/bin/bash
ps -A --format  "%c %P" --sort %mem | tail -1
