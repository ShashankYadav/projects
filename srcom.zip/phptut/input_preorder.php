<?php
 require "connector.php";
//inserting data

$item_name=$_POST['item_name'];
$cust_no=$_POST['cust_no'];
$qty=$_POST['qty'];
$cust_name=$_POST['cust_name'];
$date=$_POST['date'];
$order = "INSERT INTO preorder VALUES('$item_name','$cust_no','$qty','$cust_name','$date')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
