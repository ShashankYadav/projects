<?php
 require "connector.php";
session_start(); 
// for the admin interface pages
 //remove second condition if interface is to be normal user one!
if(empty($_SESSION['user']) || $_SESSION['user']['group'] !=1) 
{
// If they are not, we redirect them to the login page. 
 header("Location: login.php");    
  //print "not valid";
 // Remember that this die statement is absolutely critical.  Without it, 
// people can view your members-only content without logging in. 
die("Redirecting to login.php"); 
}

//inserting data

$bill_no=$_POST['bill_no'];
$cust_name=$_POST['cust_name'];
$cust_no=$_POST['cust_no'];
$issuer_id=$_POST['issuer_id'];
$issue_date=$_POST['issue_date'];
$amt=$_POST['amt'];
$order = "INSERT INTO bill VALUES('$bill_no','$cust_name','$cust_no','$issuer_id','$issue_date','$amt')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 $str="Unsuccessful";
}
 else{
$str="Successful";
}
header("Location:show.php?name=$name&str=$str&v=2");
?>
