<?php
//input.php
mysql_connect("localhost","root","");//database connection
mysql_select_db("srcom");


//inserting data order

$dealer_id = $_POST['dealer_id'];
$dealer_name= $_POST['dealer_name'];
$phone= $_POST['phone'];
$deals_in= $_POST['deals_in'];
$order = "INSERT INTO dealer VALUES('$dealer_id','$dealer_name','$phone','$deals_in')";

//declare in the order variable

$result = mysql_query($order);  //order executes

if($result){

    echo("<br>Input data is succeed");

} else{

    echo("<br>Input data is fail");

}

?>
