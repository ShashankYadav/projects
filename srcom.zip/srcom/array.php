<?php
$lst= array(
		"customer" => array("cust_no") ,
		"bill" =>array("bill_no"),
		"dealer"=>array("dealer_id"),
		"department"=>array("dno"),
		"dependent"=>array("essn","name"),
		"employee"=>array("ssn"),
		"item"=>array("item_no"),
		"manager"=>array("mgrssn"),
		"payment"=>array("tid"),
		"preorder"=>array("item_name","cust_no"),
		"receipt"=>array("tid"),
		"receives_from"=>array("tid"),
		"sells"=>array("item_no","cust_no","worker_ssn"),
		"stock"=>array("item_no"),
		"supplies"=>array("item_no"),
		"worker"=>array("wssn"),
		"users"=>array("username")
		
		);
?>