#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
#include<stdlib.h>
#include<time.h>
int edno,arno;
int artar[100]; //data to be protected
int fl[100];//if article has been selected or not
sem_t mut[100];//mutex is initialized to 1 in main
int rejart[100];//holds number of rejects for the article
int done=0;
int rejedar[100][100];//cell is set to 1 if author has prev. rejected the article
int arlist[100][100];//stores which author has which article
int ctr[100];//which author has how mant articles
void *func(void *arg)
{
	int no,wrid;
	wrid=((int)arg);
	no=rand()%arno;
	int chk;
	chk=rand();
	if(fl[no]==1 || rejedar[wrid][no]==1)//checks if article has been rejected by the author or someone else accepted it
	{
		return;
	}
//	printf("fl[no] : %d chk : %d no %d\n",fl[no],chk,no);	
	int semchk,temp;
	temp=sem_getvalue(&mut[no],&semchk);//checks if the no one is reading the article 
//	printf("semchk %d\n",semchk);
	if(semchk<=0)
	{
//		printf("sdbkajff\n");
		return;
	}
//	printf("edid : %d\n",wrid);
	sem_wait(&mut[no]);// acquire the article
//	sleep(1);
	if(chk%2==0) //rejects if even after reading
	{
		rejart[no]++;//no of rejects for the article are increased
		rejedar[wrid][no]=1;
		if(rejart[no]==edno)//if total rejects for the article = no. of editors the it is done
		{
			done++;
			fl[no]=1;
		}
		sem_post(&mut[no]);//post the article mutex
//		printf("kkkkkkkkkk\n");
		return;
	}
	fl[no]=1;
	arlist[wrid][ctr[wrid]++]=no;//added to the editors article list
	artar[no]=wrid;
	done++;//article has been accepted
	sem_post(&mut[no]);
}
int main(int argc, char *argv[])
{
	int i,j;
	edno=atoi(argv[1]);
	arno=atoi(argv[2]);
	srand(time(0));
	for(i=0;i<arno;i++)
	{
		fl[i]=0;
	}
	pthread_t edar[edno];
	int semchk,temp;
	for(i=0;i<arno;i++)
	{
		ctr[i]=0;
		rejart[i]=0;
		sem_init(&mut[i],0,1);//initialize the mutex to 1
//		temp=sem_getvalue(&mut[i],&semchk);
//		printf("mutvalue %d\n",semchk);
	}
	while(1)
	{
		for(i=0;i<edno;i++)
		{
			pthread_create(&edar[i],NULL,func,(void *)i);
		}
		
		for(i=0;i<edno;i++)
		{
			pthread_join(edar[i],NULL);
		}
		if(done==arno)
			break;
	}
	for(i=0;i<edno;i++)
	{
	//	if(fl[i]==1)
		printf("%d : ",i);
		for(j=0;j<ctr[i];j++)
		{
			printf("%d ",arlist[i][j]);//output printing
		}
		printf("\n");
	}
/*	for(i=0;i<arno;i++)
	{
		printf("%d %d\n",i,rejart[i]);
	}*/
	return 0;
}
