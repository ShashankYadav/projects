<?php
 require "connector.php";
//inserting data

$essn=$_POST['essn'];
$name=$_POST['name'];
$age=$_POST['age'];
$sex=$_POST['sex'];
$relationship=$_POST['relationship'];
$order = "INSERT INTO dependent VALUES('$essn','$name','$age','$sex','$relationship')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
