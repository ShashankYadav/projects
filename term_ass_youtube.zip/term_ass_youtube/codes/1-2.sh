#!/bin/bash
ps --format "%c %P" --deselect t | grep -v COMMAND
