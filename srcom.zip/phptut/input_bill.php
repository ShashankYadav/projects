<?php
 require "connector.php";
//inserting data

$name=$_GET['name'];
$bill_no=$_POST['bill_no'];
$cust_name=$_POST['cust_name'];
$cust_no=$_POST['cust_no'];
$issuer_id=$_POST['issuer_id'];
$issue_date=$_POST['issue_date'];
$amt=$_POST['amount'];
$order = "INSERT INTO bill VALUES('$bill_no','$cust_name','$cust_no','$issuer_id','$issue_date','$amt')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
$lin='<p><a href=\'show.php?name='.$name.'\'>'.$name.'</a></p>';
print $lin;
?>
