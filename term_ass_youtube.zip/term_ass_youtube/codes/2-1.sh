#!/bin/bash
echo -e "$*\c" 
