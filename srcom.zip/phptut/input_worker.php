<?php
 require "connector.php";
//inserting data

$wssn=$_POST['wssn'];
$dno=$_POST['dno'];
$order = "INSERT INTO worker VALUES('$wssn','$dno')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
