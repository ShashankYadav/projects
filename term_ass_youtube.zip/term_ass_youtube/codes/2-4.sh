#!/bin/bash
ps -elf | grep firefox | grep -v grep
