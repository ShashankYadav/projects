<?php
 require "connector.php";
//inserting data

$ssn=$_POST['ssn'];
$name=$_POST['name'];
$sex=$_POST['sex'];
$address=$_POST['address'];
$birthday=$_POST['birthday'];
$salary=$_POST['salary'];
$date_of_join=$_POST['date_of_join'];
$order = "INSERT INTO employee VALUES('$ssn','$name','$sex','$address','$birthday','$salary','$date_of_join')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
