using namespace std;
float temp1[16],temp2[4][4];
int m=4,n=4;
typedef struct matrixx
{
	float mat[16];
}matrix;
float transmatrix[16],modelmatrix[16],viewmatrix[16],project[4][4],porttrans[4][4],mv[16],mvp[16],ans[16];
matrix stack[1000];
float a[4][4],b[4][4];
int top=0;
float tp[4][4];
float cr,cg,cb;
int num=0;
void multmat(float aa[] ,float bb[])
{
	cout<<endl<<" aa "<<endl;
	for(int i=0;i<16;i++)
	{
		cout<<aa[i]<< " ";
		if((i+1)%4==0)
			cout<<endl;
	}
	for(int i=0;i<(4*4);i++)
	{
		a[i/4][i%4]=aa[i];
	}
	cout<<endl<<" a "<<endl;
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
			cout<<a[i][j]<<" ";
		cout<<endl;
	}
	cout<<endl<<" bb "<<endl;
	for(int i=0;i<16;i++)
	{
		cout<<bb[i]<< " ";
		if((i+1)%4==0)
			cout<<endl;
	}
	for(int i=0;i<(4*4);i++)
	{
		b[i/4][i%4]=bb[i];
	}
	cout<<endl<<" b "<<endl;
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
			cout<<b[i][j]<<" ";
		cout<<endl;
	}
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
		{
			temp2[i][j]=0;
			for(int k=0;k<4;k++)
				temp2[i][j]=temp2[i][j]+a[i][k]*b[k][j];
		}
	}
	cout<<endl<<" ANSWER of a*b "<<endl;
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
			cout<<temp2[i][j]<<" ";
		cout<<endl;
	}

/*	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
			cout<<temp2[i][j]<<" ";
		cout<<endl;
	}*/
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
		{
			temp1[i*4+j]=temp2[i][j];
		}
	/*cout<<endl<<endl<<endl;
	for(int i=0;i<16;i++)
	{
			cout<<temp1[i]<<" ";
	}
	cout<<endl;*/
}


void sglModPushMatrix()
{
	for(int i=0;i<16;i++)
			stack[top].mat[i]=modelmatrix[i];
	top++;
}
void sglModPopMatrix()
{
	if(top==0)
		return;
	for(int i=0;i<4;i++)
			modelmatrix[i]=stack[top].mat[i];
	top--;
}
