<?php
 require "connector.php";
//inserting data

$tid=$_POST['tid'];
$mgr_ssn=$_POST['mgr_ssn'];
$dealer_id=$_POST['dealer_id'];
$order = "INSERT INTO receives_from VALUES('$tid','$mgr_ssn','$dealer_id')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
