<?php
include 'array.php';
echo '<html>';
echo '<head>';
    echo ' <link rel="stylesheet" href="ministerial/default.css" type="text/css" /8:33 PM 10/30/2012>';
echo '</head>';
	$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
 	

mysql_select_db("srcom", $con);
$name=$_GET['name'];
$len=count($lst[$name]);
$arr=$lst[$name];
echo '<body>';
echo <<<'EOT'
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
			<h1>SRCOM</h1>
			</div>
			<div id="menu">
				<ul>
					<li class="current_page_item"><a href="home.php" accesskey="1" title="">Homepage</a></li>
					<li><a href="logout.php" accesskey="2" title="">LOGOUT</a></li>
				</ul>
			</div>
		</div>
	</div>
	
	<div id="page-wrapper">
		<div id="page">
			<div id="wide-content">
	
			<div>
EOT;

// show a specific tables row 
	echo '<center>';
		if($len==1)
		{	
			$val1=$_GET['value0'];
			$result=mysql_query('Select * from '.$name.' where '.$arr[0].' = "'.$val1.'";');
			
		}
		else if($len==2)
		{
			//echo $name;
		$val1=$_GET['value0'];
		$val2=$_GET['value1'];
		//echo $val1;
		//echo $val2;
			$result=mysql_query('Select * from '.$name.' where '.$arr[0].' = "'.$val1.'" and '.$arr[1].' = "'.$val2.'";');
		}
		else
		{
			$val1=$_GET['value0'];
			$val2=$_GET['value1'];
			$val3=$_GET['value2'];
			$result=mysql_query('Select * from '.$name.' where '.$arr[0].' = "'.$val1.'" and '.$arr[1].' = "'.$val2.'" and '.$arr[2].' = "'.$val3.'";');
		}
	 if (mysql_num_rows($result)>0){
		 $r = mysql_fetch_array($result,MYSQL_ASSOC);
		 echo '<table>';
		 echo '<form method="post" action="update_'.$name.'.php?name='.$name.'">';
		 foreach($r as $k => $v){
			echo '<tr>';
			echo '<td>'.$k.'</td>' ;
			 
			 if (in_array($k,$arr))
			{
				$tempo = '<td><input type ="text"  name="'.$k.'" value="'.$v.'" readonly="readonly"></td>';
			}
			else
			{
				$tempo = '<td><input type="text" name="'.$k.'" value="'.$v.'"></td>';
			}
			echo $tempo;
			echo '</tr>';
		 }
		 echo '<tr><td></td><td align="right"><input type="submit" name="submit" value="Submit"></td></tr>';
		 echo '</form>';
		 echo '</table>';
	 echo '</center>';
	echo <<<'EOT'
			</div>
		</div>
	</div>
	</div>
</div>
EOT;
}

echo '</body>';
echo '</html>';

?>