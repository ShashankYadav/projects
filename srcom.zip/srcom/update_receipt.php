<?php
 require "connector.php";
session_start(); 
// for the admin interface pages
 //remove second condition if interface is to be normal user one!
if(empty($_SESSION['user']) || $_SESSION['user']['grp'] !=1) 
{
// If they are not, we redirect them to the login page. 
 header("Location: login.php");    
  //print "not valid";
 // Remember that this die statement is absolutely critical.  Without it, 
// people can view your members-only content without logging in. 
die("Redirecting to login.php"); 
}

//inserting data

$tid=$_POST['tid'];
$from_id=$_POST['from_id'];
$given_to_ssn=$_POST['given_to_ssn'];
$date=$_POST['date'];
$order = "UPDATE receipt SET tid='$tid' , from_id='$from_id' , given_to_ssn='$given_to_ssn' , date='$date' where tid='$tid' ;";
 //declare in the order variables
$result = mysql_query($order); //order executes
if(!$result){
 $str="Unsuccessful";
}
 else{
$str="Successful";
}
$name=$_GET['name'];
header("Location:show.php?name=$name&str=$str&v=3");
?>
