<?php

	$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
 	

mysql_select_db("srcom", $con);


// show all tables
/*// list all the table in database
	
 	$result = mysql_query("show tables");
	while($row = mysql_fetch_array($result))
	{
		echo $row[0]."<br />";
	}
*/	
 	
// show all the field with type, lenght,description of a specific table
//	 $result = mysql_query("DESCRIBE table_name");
// show a specific tables row 
/*	 $result = mysql_query("SELECT * FROM customer");
	 if (mysql_num_rows($result)>0){
		 $r = mysql_fetch_array($result,MYSQL_ASSOC);
		 $table="<table><tr>";
		 $firstLine="<tr>";
		 foreach ($r as $k => $v){
		   $table .="<td>".$k."</td>";
		   $firstLine .="<td>".$v."</td>";
		 }
	 $table.="</tr>".$firstLine."</tr>";
	 while($r = mysql_fetch_array($result,MYSQL_ASSOC)){
	   $table.="<tr>";
	   foreach($r as $k => $v)
	     $table.="<td>".$v."</td>";
	   $table.="</tr>";
	 }
	  $table .="</table>";
	 echo $table;
}*/
?>