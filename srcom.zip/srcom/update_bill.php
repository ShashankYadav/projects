<?php
 require "connector.php";
session_start(); 
// for the admin interface pages
 //remove second condition if interface is to be normal user one!
if(empty($_SESSION['user'])) 
{
// If they are not, we redirect them to the login page. 
 header("Location: login.php");    
  //print "not valid";
 // Remember that this die statement is absolutely critical.  Without it, 
// people can view your members-only content without logging in. 
die("Redirecting to login.php"); 
}

//inserting data

$bill_no=$_POST['bill_no'];
$cust_name=$_POST['cust_name'];
$cust_no=$_POST['cust_no'];
$issuer_id=$_POST['issuer_id'];
$issue_date=$_POST['issue_date'];
$amt=$_POST['amt'];
$order = "UPDATE bill SET bill_no='$bill_no' , cust_name='$cust_name' , cust_no='$cust_no' , issuer_id='$issuer_id' , issue_date='$issue_date' , amt='$amt'where bill_no='$bill_no' ;";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 $str="Successful";
}
 else{
$str="Unsuccessful";
}
$name=$_GET['name'];
header("Location:show.php?name=$name&str=$str&v=3");
?>
