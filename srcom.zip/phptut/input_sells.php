<?php
 require "connector.php";
//inserting data

$item_no=$_POST['item_no'];
$cust_no=$_POST['cust_no'];
$worker_ssn=$_POST['worker_ssn'];
$order = "INSERT INTO sells VALUES('$item_no','$cust_no','$worker_ssn')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
