import re,collections,sys
def words(text): return re.findall('[a-z]+', text.lower()) 
NWORDS = words(file('dict').read())
alphabet = 'abcdefghijklmnopqrstuvwxyz'

def main1(word):
	spl=[]
	for i in range(len(word)+1):
		spl.append((word[:i],word[i:]))
	nu=[]
	for i,j in spl:
		if j:
			nu.append(i+j[1:])
	for i,j in spl:
		flag=0
		if len(j)>1:
			z=i+j[1]+j[0]+j[2:]
			for x in nu:
				if x == z:
					flag=1
				if flag==0:
					nu.append(z)
	for i,j in spl:
		for k in alphabet:
			flag=0
			if j:
				z=i+k+j[1:]
				for x in nu:
					if x == z:
						flag=1
					if flag==0:
						nu.append(z)
	for i,j in spl:
		for k in alphabet:
			flag=0
			if j:
				z=i+k+j
				for x in nu:
					if x == z:
						flag=1
					if flag==0:
						nu.append(z)

	return nu
def known(words):
	ans=[]
	for w in words:
		if w in NWORDS:
			ans.append(w)
	return ans
def known_edits2(word):
    #return set(e2 for e1 in edits1(word) for e2 in edits1(e1) if e2 in NWORDS)
	ans2=[]
	for e1 in correct(word):
		for e2 in correct(e1):
			if e2 in NWORDS:
				ans2.append(e2)
	return ans2
def correct(word):
	#candidates = known([word]) or known(delete(word)) or known(tr(word)) or known(rep(word)) or known(ins(word)) or [word]
    	an=[]
	an=known(main1(word))
	an2=known([word])
    	for i in an:
		print i
	for i in an2:
		print i
correct(sys.argv[1])
