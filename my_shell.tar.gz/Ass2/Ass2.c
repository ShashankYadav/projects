#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <wait.h>
#include<errno.h>
//#include<perror.h>
char st[300];
char *home;
int counter=0;
struct commands
{
	int cno;
	char *st[100];
	pid_t pid;
	int runfl;
};
struct commands cst[1000];

void shellprompt()
{
	char* str;
	char str1[100];
	str= getenv("USER");
	printf("%s@",str);
	gethostname(str1,99);
	printf("%s : ",str1);
}

typedef void (*sighandler_t)(int);
char c = '\0';

void handle_signal(int signo)
{
	fflush(stdout);
	return;
}

void child_handler(int signum){
	int pid,found=0;
	pid = waitpid(WAIT_ANY, NULL, WNOHANG);
	if(pid!=-1)
	{
		int j=0;
		char *name;
		for(j=0;j<counter;j++)
		{
			if(cst[j].pid==pid)
			{	name=cst[j].st[0];
				found=1;
				break;
			}
		}
		if(found==0)
			return;
		int lon=strlen(name)-1;
		if(name[lon]=='&')
			name[lon]='\0';
		if(cst[j].runfl==1)
			cst[j].runfl=0;
		if(pid != -1){
			printf("%s %d exited normally\n",name,pid);
		}
	}
	signal(SIGCHLD, child_handler);
	return;
}
void exe (char**);
void pip(char **arr)
{
	int flout=0,flin=0,l=0,k,countpipe=0,cntr=0,posin,posout,posocntr,posicntr;
	char *commandlist[100][10];
	for(k=0;arr[k]!=NULL;k++)
	{
//		printf("%s ",arr[k]);
		if(strcmp(arr[k],">")==0)
		{
			flout=1;
			posout=l;
			posocntr=cntr;
		}
		if(strcmp(arr[k],"<")==0)
		{
			flin=1;
			posin=l;
			posicntr=cntr;
		}
		
		if(strcmp(arr[k],"|")==0)
		{
			countpipe++;
			commandlist[cntr][l]=NULL;
			cntr++;
			l=0;
//			printf("\n");
			continue;
		}
		commandlist[cntr][l++]=strdup(arr[k]);
//		printf("%s ",commandlist[cntr][l-1]);
	}
//	printf("\n");
	commandlist[cntr+1][0]=NULL;
	
	int m;
	int status;
	int i=0;
	pid_t pid;
	int pipefd[2*countpipe];
	for(i = 0; i < (countpipe); i++){
		if(pipe(pipefd + i*2) < 0) {
//			perror("couldn't pipe");
			return;
		}
	}
//	printf("pipes made\n");
	int j=0;
	l=0;
	while(commandlist[l][0]!=NULL)
	{
		pid=fork();
		if(pid==0)
		{
			if(flin==1 && l==posicntr)
			{
				int yy;
				char *infile;
				infile=strdup(commandlist[posicntr][posin+1]);
				FILE *f1=fopen(infile,"r");
				if(f1==NULL)
				{
					printf("File dosen't exist\n");
					exit(0);
					return;
				}
				dup2(fileno(f1),0);
				commandlist[posicntr][posin]=NULL;
				fclose(f1);
			}
			if(commandlist[l+1][0]!=NULL)
			{
				if(dup2(pipefd[j + 1], 1) < 0){
					//					perror("dup2");
					return;
				}

			}


			if(j != 0 ){
				if(dup2(pipefd[j-2], 0) < 0){
					//					perror(" dup2");///j-2 0 j+1 1
					return;

				}
			}
			if(flout==1 && l==posocntr)
			{
				int n;
				char line[100];
				char *outfile=strdup(commandlist[posocntr][posout+1]);
				FILE *f1=fopen(outfile,"w");
				commandlist[posocntr][posout]=NULL;
				int yy=0;
				dup2(fileno(f1),1);
				fclose(f1);
			}
			for(i = 0; i < 2*countpipe; i++){
				close(pipefd[i]);
			}
//			if( execvp(*commandlist[l], commandlist[l]) < 0 ){
//				return;
//			}
			exe(commandlist[l]);
			exit(0);

		}
		else if(pid < 0)
		{
			return;
		}
		j=j+2;
		l++;
	}
	for(i = 0; i < 2 * countpipe; i++){
		close(pipefd[i]);
	}

	for(i = 0; i < countpipe + 1; i++)
		wait(&status);
}
void inout(char **arr)
{
	int posin=0,posout=0,k=0,wk=0,in, out,flin=0,flout=0;

	// open input and output files
	for(k=0;arr[k]!=NULL;k++)
	{
		if(strcmp(arr[k],"<")==0)
		{	
			posin=k;
			flin=1;
		}
		if(strcmp(arr[k],">")==0)
		{
			flout=1;
			posout=k;
		}
	}
	char *command[50];
	int yy=0;
	
	char *infile;
	char *outfile;
	if(flin==1 && flout==1)
	{
		for(yy=0;yy<posin;yy++)
		{
			command[yy]=strdup(arr[yy]);
		}
		command[posin]=NULL;
		if(fork()==0)
		{
			infile=strdup(arr[posin+1]);
			outfile=strdup(arr[posout+1]);
			FILE *in = fopen(infile, "r");
			if(in==NULL)
			{
				printf("File dosen't exist\n");
				exit(0);
				return;
			}
			FILE *out = fopen(outfile, "w");
			dup2(fileno(in), 0);
			dup2(fileno(out), 1);
			fclose(in);
			fclose(out);
			execvp(*command, command);
		}
		else
		{
			int status=0;
			wait(&status);
			return;
		}
	}
	if(flout==1)
	{
		for(yy=0;yy<posout;yy++)
		{
			command[yy]=strdup(arr[yy]);
		}
		command[posout]=NULL;
		if(fork()==0)
		{
			outfile=strdup(arr[posout+1]);
			FILE *out = fopen(outfile, "w");
			dup2(fileno(out), 1);
			fclose(out);
			execvp(*command, command);
		}
		else
		{
			int status=0;
			wait(&status);
			return;
		}
	}
	if(flin==1)
	{
		for(yy=0;yy<posin;yy++)
		{
			command[yy]=strdup(arr[yy]);
		}
		command[posin]=NULL;
		if(fork()==0)
		{
			infile=strdup(arr[posin+1]);
			FILE *in = fopen(infile, "r");
			if(in==NULL)
			{
				printf("File dosen't exist\n");
				exit(0);
				return;
			}
			dup2(fileno(in), 0);
			fclose(in);
			execvp(*command, command);
		}
		else
		{
			int status=0;
			wait(&status);
			return;
		}
	}
}
void exe(char **arr)
{
	signal(SIGINT, SIG_IGN);
	signal(SIGINT, handle_signal);
	signal(SIGCHLD, child_handler);
	pid_t pid;
	int bg=0,lenstr,k=0;
	for(k=0;arr[k]!=NULL;k++);
	int wj=0,fla1=0,fla2=0,fla3=0,pos1=0,pos2=0,pos3=0,cntr=0;
//	printf("\n\nreceived: \n");
	for(wj=0;wj<k;wj++)
	{
//		printf("%s ",arr[wj]);
		if(strcmp(arr[wj],"|")==0)
		{
			fla1=1;
			pos1=cntr++;
		}
		if(strcmp(arr[wj],"<")==0)
		{	fla2=1;
			pos2=cntr++;	
		}
		if(strcmp(arr[wj],">")==0)
		{	fla3=1;
			pos3=cntr++;
		}

	}
//	printf("\n\n\n");
	if(pos3<pos2)
	{
		printf("usage: command < infile > outfile\n");
		return;
	}
	if(fla1==0 && (fla2==1 || fla3==1))
	{
		int j=0;
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		cst[counter].cno=counter+1;
		counter=counter+1;
		inout(arr);
		fflush(stdin);
		fflush(stdout);
		return;
	}
	if(fla1==1)
	{
		int j=0;
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		cst[counter].cno=counter+1;
		counter=counter+1;
		pip(arr);
		fflush(stdin);
		fflush(stdout);
		return;
	}
	if(strcmp(arr[0],"cd")==0)
	{
		if(k==1)
		{
			chdir(home);
			cst[counter].cno=counter+1;
			int j=0;
			for(j=0;arr[j]!=NULL;j++)
				cst[counter].st[j]=strdup(arr[j]);
			cst[counter].pid=getpid();
			counter=counter+1;
			return;
		}
		if(strcmp(arr[1],"~")==0)
		{	chdir(home);
			cst[counter].cno=counter+1;
			int j=0;
			for(j=0;arr[j]!=NULL;j++)
				cst[counter].st[j]=strdup(arr[j]);
			cst[counter].pid=getpid();
			counter=counter+1;
			return;
		}
		if(k>1)
		{
			cst[counter].cno=counter+1;
			int j=0;
			for(j=0;arr[j]!=NULL;j++)
				cst[counter].st[j]=strdup(arr[j]);
			cst[counter].pid=getpid();
			counter=counter+1;
			chdir(arr[1]);
			return;
		}
	}
	if(arr[0][0]=='h' && arr[0][1]=='i' && arr[0][2]=='s' && arr[0][3]=='t' &&arr[0][4]=='\0')
	{
		int j=0,lo=0;	
		for(j=0;j<counter;j++)
		{
			printf("%d.",j+1);
			for(lo=0;cst[j].st[lo]!=NULL;lo++)
				printf("%s ",cst[j].st[lo]);
			printf("\n");
		}
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		cst[counter].cno=counter+1;
		counter=counter+1;
		return;
	}
	if(arr[0][0]=='!' && arr[0][1]=='h' && arr[0][2]=='i' && arr[0][3]=='s' && arr[0][4]=='t' && 0<arr[0][5]-'0'<=9)
	{
		int j=0,lo=0,numbah=0;	
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		cst[counter].cno=counter+1;
		counter=counter+1;
		for(lo=5;lo<=strlen(arr[0])-1;lo++)
			numbah=10*numbah+(arr[0][lo]-'0');
//		printf("numbah: %d\n",numbah);
		/*for(j=0;cst[numbah-1].st[j]!=NULL;j++)
		{
			printf("%s ",cst[numbah-1].st[j]);
		}
		printf("\n");
//		return;*/
		if(numbah>counter||numbah==0)
		{
			printf("try another number\n");
			return;
		}
		else
				exe(cst[numbah-1].st);
		return;
	}		
	if(arr[0][0]=='h' && arr[0][1]=='i' && arr[0][2]=='s' && arr[0][3]=='t' &&0<arr[0][4]-'0'<=9)
	{
		int lo,j,numbah=0;
		for(lo=strlen(arr[0])-1;lo>=4;lo--)
			numbah=10*numbah+(arr[0][lo]-'0');
		for(j=counter-numbah;j<counter;j++)
		{
			printf("%d.",j-(counter-numbah)+1);
			for(lo=0;cst[j].st[lo]!=NULL;lo++)
				printf("%s ",cst[j].st[lo]);
			printf("\n");
		}
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		cst[counter].cno=counter+1;
		counter=counter+1;
		return;
	}
	if(strcmp(arr[0],"pid")==0 && arr[1]==NULL)
	{
		cst[counter].cno=counter+1;
		int j=0;
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		counter=counter+1;
		if(k==1)
		{
			printf("./a.out pid=%d\n",getpid());
		}
		return;
	}
	if(strcmp(arr[0],"pid")==0 && strcmp(arr[1],"all")==0)
	{
		int j=0,lo=0;
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		cst[counter].cno=counter+1;
		counter=counter+1;
		for(j=0;j<counter;j++)
		{
			printf("command name: ");
			for(lo=0;cst[j].st[lo]!=NULL;lo++)
				printf("%s ",cst[j].st[lo]);
			printf("process id: %d",cst[j].pid);
			printf("\n");
		}
		return;
	}
	if(strcmp(arr[0],"pid")==0 && strcmp(arr[1],"current")==0)
	{
		int j=0,lo=0;
		for(j=0;arr[j]!=NULL;j++)
			cst[counter].st[j]=strdup(arr[j]);
		cst[counter].pid=getpid();
		cst[counter].cno=counter+1;
		counter=counter+1;
		for(j=0;j<counter;j++)
		{	
			if(cst[j].runfl==1)
			{
				printf("command name: ");
				for(lo=0;cst[j].st[lo]!=NULL;lo++)
					printf("%s ",cst[j].st[lo]);
				printf("process id: %d",cst[j].pid);
				printf("\n");
			}
		}
		return;
	}
	
	lenstr=strlen(arr[0]);
	int ufl=0,fl=0;
	if(arr[1]==NULL)
	{
		bg=0;
		fl=1;
	}
	if((strcmp(arr[0],"ls")==0) && (arr[1]==NULL))
	{
		cst[counter].pid=getpid();
		ufl=1;
	}
	int j=0;
	for(j=0;arr[j]!=NULL;j++)
		cst[counter].st[j]=strdup(arr[j]);
	if(fl==0)
	{
		int cntr=0;
		for(cntr=0;arr[cntr]!=NULL;cntr++);
		if(strcmp(arr[cntr-1],"&")==0)
		{
			arr[cntr-1]=NULL;
			bg=1;
		}
		else
			bg=0;
	}
	
	int fla=0;
	cst[counter].cno=counter+1;
	counter=counter+1;
	int p=0;
	if(bg==0)
	{
		if((pid=fork())==0)
		{	
			int retval=0;
			retval=execvp(*arr,arr);
			if(retval==-1)
				exit(0);
			return;
		}
		else
		{
			if(ufl==0)
				cst[counter-1].pid=pid;
			wait(&p);
		}
		fflush(stdin);
		fflush(stdout);
		return;
	}
	else
	{
		if((pid=fork())==0)
		{
//			int retval=0;
			execvp(*arr,arr);
//			if(retval==-1)
//				_exit(0);
		}
		else
		{
			printf("%d",pid);
			cst[counter-1].pid=pid;
			cst[counter-1].runfl=1;
		}
		return;
	}
	
}
void get_rest(int n,int k,char *ptr,char *rest)
{
		int i=0,j=0;
			for(i=n;i<k;i++)
						rest[j++]=ptr[i];
				rest[j]='\0';
}
int ip()
{
	signal(SIGQUIT, handle_signal);
	signal(SIGTSTP, handle_signal);
	signal(SIGINT, handle_signal);
	signal(SIGCHLD, child_handler);
//	signal(SIGINT, SIG_IGN);
//	signal(SIGINT, handle_signal);
//	signal(SIGCHLD, child_handler);
	int i=0;
	st[0]='\0';
	scanf("%[^\n]",st);
	scanf("%c",&c);	
	char* arr[50];
	char *temp=NULL;
	temp=strtok(st," ");
	if(temp==NULL)
		return 0;	
	arr[i++]=strdup(temp);
	while(1)
	{
		temp=strtok(NULL," ");
		if(temp==NULL)
			break;
		arr[i]=strdup(temp);
		i++;
	}
	arr[i]= NULL;
	if(strcmp(arr[0],"quit")==0)
		return -1;
	exe(arr);
	fflush(stdin);
	fflush(stdout);
	return 0;
}
//int runner=0;
int main(int argc, char *argv[], char *envp[])
{
//	signal(SIGINT, SIG_IGN);
//	signal(SIGQUIT,SIG_IGN);
//	signal(SIGTSTP,SIG_IGN);
	signal(SIGQUIT, handle_signal);
	signal(SIGTSTP, handle_signal);
	signal(SIGINT, handle_signal);
	signal(SIGCHLD, child_handler);
	int flag=0,i,k,chk=0;
	long size;
	char *dir;
	char *ptr;
	size=pathconf(".", _PC_PATH_MAX);
	if ((dir = (char *)malloc((size_t)size)) != NULL)
	{
		if(flag==0) ptr = getcwd(dir, (size_t)size);
		else getcwd(dir,(size_t)size);
		flag++;
	}
	home=ptr;
//	printf("home : %s\n",home);
	while(1)
	{
//		runner++;
//		if(runner>6)
//			exit(0);
	char *buf;
	char rest[100];
	shellprompt();
	size=pathconf(".", _PC_PATH_MAX);
	if ((dir = (char *)malloc((size_t)size)) != NULL)
	{
		if(flag==0) ptr = getcwd(dir, (size_t)size);
		else getcwd(dir,(size_t)size);
		flag++;
	}
	if(strlen(dir)<strlen(ptr)) printf("%s>",dir);
	else
	{
		printf("~");
		get_rest(strlen(ptr),strlen(dir),dir,rest);
		if(rest!=NULL) printf("%s",rest);
		printf(">");
	}
		fflush(stdin);
		fflush(stdout);
		chk=ip();
		if(chk==-1)
			break;	

	}
	return 0;

}
