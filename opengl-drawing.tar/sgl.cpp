#include<cmath>
#include<stdio.h>
#include<GL/glut.h>
#include "matrix.cpp"

using namespace std;

int SGL_TRIANGLES=1;
typedef struct sekai
{
	float x,y,z,r,g,b;
}world;
world wor[1000];
void rotate(float angle, float x, float y, float z)
{
	float c=cos(angle);
	float s=sin(angle);
	float l=sqrt(x*x+y*y+z*z);
	if(l!=1)
	{
		x=x/l;
		y=y/l;
		z=z/l;
	}
	transmatrix[0]=x*x*(1-c) + c;
	transmatrix[1]=x*y*(1-c) - (z*s);
	transmatrix[2]=x*z*(1-c) + (y*s);
	transmatrix[3]=0;
	
	transmatrix[4]=y*x*(1-c) + (z*s);
	transmatrix[5]=y*y*(1-c) + c;
	transmatrix[6]=y*z*(1-c) - (x*s);
	transmatrix[7]=0;
	
	transmatrix[8]=x*z*(1-c) - (y*s);
	transmatrix[9]=y*z*(1-c) + (x*s);
	transmatrix[10]=z*z*(1-c) + c;
	transmatrix[11]=0;
	
	transmatrix[12]=0;
	transmatrix[13]=0;
	transmatrix[14]=0;
	transmatrix[15]=1;

	m=n=4;
	

	
}

void translate(float x, float y,float z)
{
	transmatrix[0]=1;
	transmatrix[1]=0;
	transmatrix[2]=0;
	transmatrix[3]=x;
	
	transmatrix[4]=0;
	transmatrix[5]=1;
	transmatrix[6]=0;
	transmatrix[7]=y;
	
	transmatrix[8]=0;
	transmatrix[9]=0;
	transmatrix[10]=1;
	transmatrix[11]=z;
	
	transmatrix[12]=0;
	transmatrix[13]=0;
	transmatrix[14]=0;
	transmatrix[15]=1;

	m=n=4;
}

void scale(float x, float y, float z)
{
	transmatrix[0]=x;
	transmatrix[1]=0;
	transmatrix[2]=0;
	transmatrix[3]=0;
	
	transmatrix[4]=0;
	transmatrix[5]=y;
	transmatrix[6]=0;
	transmatrix[7]=0;
	
	transmatrix[8]=0;
	transmatrix[9]=0;
	transmatrix[10]=z;
	transmatrix[11]=0;
	
	transmatrix[12]=0;
	transmatrix[13]=0;
	transmatrix[14]=0;
	transmatrix[15]=1;

	m=n=4;
	
}

void modify(float mat[16])
{
	for(int i=0;i<16;i++)
		transmatrix[i]=mat[i];
	m=n=4;
	
}

void sglModRotate(float angle,float x,float y,float z)
{
	rotate(angle,x,y,z);	
	multmat(modelmatrix,transmatrix);
	for(int i=0;i<16;i++)
			modelmatrix[i]=temp1[i];
}

void sglModTranslate(float x, float y, float z)
{
	translate(x,y,z);
	multmat(modelmatrix,transmatrix);
	for(int i=0;i<16;i++)
			modelmatrix[i]=temp1[i];
}

void sglModScale(float x,float y,float z)
{
	scale(x,y,z);
	multmat(modelmatrix,transmatrix);
for(int i=0;i<16;i++)
			modelmatrix[i]=temp1[i];
	cout<< "scaling "<<endl;
	for(int i=0;i<16;i++)
	{
		cout<<modelmatrix[i]<<" ";
		if((i+1)%4==0)
			cout<<endl;
	}
}

void sglModMatrix(float mat[16])
{
	modify(mat);	
	multmat(modelmatrix,transmatrix);
for(int i=0;i<16;i++)
			modelmatrix[i]=temp1[i];
}

void sglModLoadIdentity()
{
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			{
				if(i==j)
					modelmatrix[i*4+j]=1;
				else
					modelmatrix[i*4+j]=0;
			}
	
}

void sglViewRotate(float angle,float x,float y,float z)
{
	rotate(angle,x,y,z);
	multmat(viewmatrix,transmatrix);
	for(int i=0;i<16;i++)
			viewmatrix[i]=temp1[i];
}

void sglViewTranslate(float x, float y, float z)
{
	translate(x,y,z);
	multmat(viewmatrix,transmatrix);
	for(int i=0;i<16;i++)
			viewmatrix[i]=temp1[i];
}

void sglViewMatrix(float mat[16])
{
	modify(mat);	
	multmat(viewmatrix,transmatrix);
	for(int i=0;i<16;i++)
			viewmatrix[i]=temp1[i];
}

void sglViewLoadIdentity()
{
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			{
				if(i==j)
					viewmatrix[i*4+j]=1;
				else
					viewmatrix[i*4+j]=0;
			}	
}


void sglLookAt(float eyex,float eyey,float eyez,float centerx,float centery,float centerz,float upx,float upy,float upz)
{
	float fx=centerx-eyex, fy=centery-eyey, fz=centerz-eyez;
	float lf=sqrt( fx*fx + fy*fy + fz*fz );
	fx=fx/lf;
	fy=fy/lf;
	fz=fz/lf;
	float lu=sqrt( upx*upx + upy*upy + upz*upz );
	upx=upx/lu;
	upy=upy/lu;
	upz=upz/lu;

	float sx= fy*upz - fz*upy, sy= fz*upx - fx*upz, sz= fx*upy - fy*upx;
	lu=sqrt( sx*sx + sy*sy + sz*sz );
	sx=sx/lu;
	sy=sy/lu;
	sz=sz/lu;
	float ux= sy*fz - sz*fy, uy= sz*fx -sx*fz, uz= sx*fy - sy*fx;
	lu=sqrt( ux*ux + uy*uy + uz*uz );
	ux=ux/lu;
	uy=uy/lu;
	uz=uz/lu;

	transmatrix[0]=sx;
	transmatrix[1]=sy;
	transmatrix[2]=sz;
	transmatrix[3]=0;
	
	transmatrix[4]=ux;
	transmatrix[5]=uy;
	transmatrix[6]=uz;
	transmatrix[7]=0;
	
	transmatrix[8]=-fx;
	transmatrix[9]=-fy;
	transmatrix[10]=-fz;
	transmatrix[11]=0;;

	
	transmatrix[12]=0;
	transmatrix[13]=0;
	transmatrix[14]=0;
	transmatrix[15]=1;

	m=n=4;
	multmat(viewmatrix,transmatrix);
	for(int i=0;i<16;i++)
			viewmatrix[i]=temp1[i];
	translate(-eyex,-eyey,-eyez);
	multmat(viewmatrix,transmatrix);
	for(int i=0;i<16;i++)
			viewmatrix[i]=temp1[i];
}

void sglProjOrtho(float left,float right,float bottom,float top,float near,float far)
{
	float tx = (right+left)/(left-right) , ty= (top+bottom)/(bottom-top) , tz= (far+near)/(near-far);
	
	project[0][0]=2/(right-left);
	project[0][1]=0;
	project[0][2]=0;
	project[0][3]=tx;

	project[1][0]=0;
	project[1][1]=2/(top-bottom);
	project[1][2]=0;
	project[1][3]=ty;

	project[2][0]=0;
	project[2][1]=0;
	project[2][2]=2/(near-far);
	project[2][3]=tz;

	project[3][0]=0;
	project[3][1]=0;
	project[3][2]=0;
	project[3][3]=1;

}

void sglProjFrustum(float left,float right,float bottom,float top,float near,float far)
{
	float a = (right+left)/(right-left) , b= (top+bottom)/(top-bottom) , c= (far+near)/(near-far), d= (2 * far * near )/(near-far);
	
	project[0][0]=(2*near)/(right-left);
	project[0][1]=0;
	project[0][2]=a;
	project[0][3]=0;

	project[1][0]=0;
	project[1][1]=(2*near)/(top-bottom);
	project[1][2]=b;
	project[1][3]=0;

	project[2][0]=0;
	project[2][1]=0;
	project[2][2]=c;
	project[2][3]=d;

	project[3][0]=0;
	project[3][1]=0;
	project[3][2]=-1;
	project[3][3]=0;
	
}

void sglProjectLoadIdentity()
{
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
			if(i==j)
				project[i][j]=1;
			else
				project[i][j]=0;
	}
}

void sglPortLoadIdentity()
{
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
			if(i==j)
				porttrans[i][j]=1;
			else
				porttrans[i][j]=0;
	}
}

void sglViewport(float x,float y,float w,float h)
{
	porttrans[0][0]=(w-x)/2;
	porttrans[0][1]=0;
	porttrans[0][2]=(w+x)/2;
	porttrans[0][3]=0;


	porttrans[1][0]=0;
	porttrans[1][1]=(h-y)/2;
	porttrans[1][2]=(h+y)/2;
	porttrans[1][3]=0;


	porttrans[2][0]=0;
	porttrans[2][1]=0;
	porttrans[2][2]=1;
	porttrans[2][3]=0;

	porttrans[3][0]=0;
	porttrans[3][1]=0;
	porttrans[3][2]=0;
	porttrans[3][3]=1;
/*	float coord[3][1];
	coord[0][0]=xn;
	coord[1][0]=yn;
	coord[2][0]=1;
	*/
	//glViewport(x,y,w,h);
}

float tmp1[16],tmp2[16];
void makematrix()
{
	int i,j;
	cout<<"----------------------------------------------------"<<endl;
	cout<<" modelmatrix " <<endl;
	for( i=0;i<16;i++)
	{
		cout<<modelmatrix[i]<<" ";
		if(i==3 ||i==7 || i==11 || i==15)
			cout<<endl;
	}
	cout<<" viewmatrix " <<endl;
	for( i=0;i<16;i++)
	{
		cout<<viewmatrix[i]<<" ";
		if(i==3 ||i==7 || i==11 || i==15)
			cout<<endl;
	}
	cout<<" project " <<endl;
	for( i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
			cout<<project[i][j]<<" ";
	//	if(i==3 ||i==7 || i==11 || i==15)
			cout<<endl;
	}
	cout<<" viewportmatrix " <<endl;
	for( i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
			cout<<porttrans[i][j]<<" ";
	//	if(i==3 ||i==7 || i==11 || i==15)
			cout<<endl;
	}
	cout<<"-----------------------------------------------------------------"<<endl;
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			tmp1[i*4+j]=modelmatrix[i*4+j];
		}
	}
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			tmp2[i*4+j]=viewmatrix[i*4+j];
		}
	}
	m=n=4;
	multmat(tmp2,tmp1);
	for(i=0;i<16;i++)
	{
		mv[i]=temp1[i];
	}
	cout<<"mv "<<endl;
	for(i=0;i<16;i++)
		cout<<mv[i]<<" ";
	cout<<endl;
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			tmp1[i*4+j]=project[i][j];
		}
	}
	m=n=4;
	
	multmat(tmp1,mv);
	
	for(i=0;i<16;i++)
		mvp[i]=temp1[i];
	cout<<"mvp "<<endl;
	for(i=0;i<16;i++)
		cout<<mvp[i]<<" ";
	cout<<endl;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++)
		{
			tmp1[i*4+j]=porttrans[i][j];
		}
	
	multmat(tmp1,mvp);
	
	for(i=0;i<16;i++)
		ans[i]=temp1[i];
	cout<<"ans "<<endl;
	for(i=0;i<16;i++)
		cout<<ans[i]<<" ";
	cout<<endl;
}

float ans2[4][4];
int fl=0;
void sglBegin(int SGL_TRIANGLES)
{
	glBegin(GL_TRIANGLES);
	/*makematrix();
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			ans2[i][j]=ans[i*4+j];
	*/
	fl=1;
}

void sglEnd()
{
	glEnd();
	fl=0;
}
void sglColour(float r,float g, float b)
{
	cr=r;
	cg=g;
	cb=b;
	glColor3f(r,g,b);
}
void sglClear()
{
	glClear(GL_COLOR_BUFFER_BIT);
}
void sglVertex(float x,float y,float z)
{
	if(fl==1)
	{
		wor[num].x=x;
		wor[num].y=y;
		wor[num].z=z;
		wor[num].r=cr;
		wor[num].g=cg;
		wor[num].b=cb;
		num++;
	}
	/*
	float nx,ny,nz,nw=1;
	cout<<" x "<<x<<" y "<<y<<" z "<<z<<endl;
	nx=mvp[0]*x+mvp[1]*y+mvp[2]*z+mvp[3]*1;
	ny=mvp[4]*x+mvp[5]*y+mvp[6]*z+mvp[7]*1;
	nz=mvp[8]*x+mvp[9]*y+mvp[10]*z+mvp[11]*1;
	nw=mvp[12]*x+mvp[13]*y+mvp[14]*z+mvp[15]*1;
	nx=nx/nw;
	ny=ny/nw;
	nz=nz/nw;
	cout<<"mvp"<<endl;
	for(int i=0;i<16;i++)
		cout<<mvp[i]<<" ";
	cout<<endl;
	cout<<endl<<"nx : "<<nx<<" ny "<<ny<<" nz "<<nz<<" nw "<<nw<<endl;
//	glVertex3f(nx,ny,nz);
	float sx,sy,sz=1,sw=1;
	sx=porttrans[0][0]*nx+porttrans[0][1]*ny+porttrans[0][2]*1+porttrans[0][3]*1;
	sy=porttrans[1][0]*nx+porttrans[1][1]*ny+porttrans[1][2]*1+porttrans[1][3]*1;
	sz=porttrans[2][0]*nx+porttrans[2][1]*ny+porttrans[2][2]*1+porttrans[2][3]*1;
	sw=porttrans[3][0]*nx+porttrans[3][1]*ny+porttrans[3][2]*1+porttrans[3][3]*1;
	cout<<endl<<"sx : "<<sx<<" sy "<<sy<<" sz "<<sz<<" sw "<<sw<<endl;
	
	//glLoadMatrixf(ans);
	//glVertex3f(x,y,z);
	glVertex3f(sx,sy,nz);
	*/
}

int writefl=1;
void sglClear(float r,float g,float b)
{
	glClearColor(r,g,b,1.0);
}
void sglShow()
{
	makematrix();
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			ans2[i][j]=ans[i*4+j];
	float x,y,z;
	float nx,ny,nz,nw=1;
	glBegin(GL_TRIANGLES);
	if(writefl==0)
	{
		for(int i=0;i<num;i++)
		{
			x=wor[i].x;
			y=wor[i].y;
			z=wor[i].z;
			glColor3f(wor[i].r,wor[i].g,wor[i].b);

			cout<<" x "<<x<<" y "<<y<<" z "<<z<<endl;
			nx=mvp[0]*x+mvp[1]*y+mvp[2]*z+mvp[3]*1;
			ny=mvp[4]*x+mvp[5]*y+mvp[6]*z+mvp[7]*1;
			nz=mvp[8]*x+mvp[9]*y+mvp[10]*z+mvp[11]*1;
			nw=mvp[12]*x+mvp[13]*y+mvp[14]*z+mvp[15]*1;
			nx=nx/nw;
			ny=ny/nw;
			nz=nz/nw;
			cout<<"mvp"<<endl;
			for(int i=0;i<16;i++)
				cout<<mvp[i]<<" ";
			cout<<endl;
			cout<<endl<<"nx : "<<nx<<" ny "<<ny<<" nz "<<nz<<" nw "<<nw<<endl;
			//	glVertex3f(nx,ny,nz);
			float sx,sy,sz=1,sw=1;
			sx=porttrans[0][0]*nx+porttrans[0][1]*ny+porttrans[0][2]*1+porttrans[0][3]*1;
			sy=porttrans[1][0]*nx+porttrans[1][1]*ny+porttrans[1][2]*1+porttrans[1][3]*1;
			sz=porttrans[2][0]*nx+porttrans[2][1]*ny+porttrans[2][2]*1+porttrans[2][3]*1;
			sw=porttrans[3][0]*nx+porttrans[3][1]*ny+porttrans[3][2]*1+porttrans[3][3]*1;
			cout<<endl<<"sx : "<<sx<<" sy "<<sy<<" sz "<<sz<<" sw "<<sw<<endl;

			//glLoadMatrixf(ans);
			//glVertex3f(x,y,z);
			glVertex3f(sx,sy,nz);
		}
	}
	if(writefl==1)
	{
		FILE *fptr;
		fptr=fopen("temp.ply","w");
		for(int i=0;i<num;i++)
		{
			x=wor[i].x;
			y=wor[i].y;
			z=wor[i].z;
			glColor3f(wor[i].r,wor[i].g,wor[i].b);

			cout<<" x "<<x<<" y "<<y<<" z "<<z<<endl;
			nx=mvp[0]*x+mvp[1]*y+mvp[2]*z+mvp[3]*1;
			ny=mvp[4]*x+mvp[5]*y+mvp[6]*z+mvp[7]*1;
			nz=mvp[8]*x+mvp[9]*y+mvp[10]*z+mvp[11]*1;
			nw=mvp[12]*x+mvp[13]*y+mvp[14]*z+mvp[15]*1;
			nx=nx/nw;
			ny=ny/nw;
			nz=nz/nw;
			cout<<"mvp"<<endl;
			for(int i=0;i<16;i++)
			{
				cout<<mvp[i]<<" ";
			}
			cout<<endl;
			cout<<endl<<"nx : "<<nx<<" ny "<<ny<<" nz "<<nz<<" nw "<<nw<<endl;
			//	glVertex3f(nx,ny,nz);
			float sx,sy,sz=1,sw=1;
			sx=porttrans[0][0]*nx+porttrans[0][1]*ny+porttrans[0][2]*1+porttrans[0][3]*1;
			sy=porttrans[1][0]*nx+porttrans[1][1]*ny+porttrans[1][2]*1+porttrans[1][3]*1;
			sz=porttrans[2][0]*nx+porttrans[2][1]*ny+porttrans[2][2]*1+porttrans[2][3]*1;
			sw=porttrans[3][0]*nx+porttrans[3][1]*ny+porttrans[3][2]*1+porttrans[3][3]*1;
			cout<<endl<<"sx : "<<sx<<" sy "<<sy<<" sz "<<sz<<" sw "<<sw<<endl;

			//glLoadMatrixf(ans);
			//glVertex3f(x,y,z);
			glVertex3f(sx,sy,nz);
			if(fptr!=NULL)
			{
				fprintf(fptr,"%f %f %f %f %f %f\n",sx,sy,nz,wor[i].r,wor[i].g,wor[i].b);
			}
		}
		writefl=0;
		fclose(fptr);
	}
	glEnd();
}
