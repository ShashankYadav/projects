<?php
include 'array.php';
	session_start(); 
// for the admin interface pages
//remove second condition if interface is to be normal user one!
	
if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: login.php"); 
         //print "not valid";
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to login.php"); 
    } 
//confirmation done regarding the interface of stuff
echo '<html>';
echo '<head>';
    echo ' <link rel="stylesheet" href="ministerial/default.css" type="text/css src="myscript.php"" /8:33 PM 10/30/2012>';
	echo '<script type="text/javascript">';

    //if clicked Yes open new page if Cancel stay on the page 
    echo'function popup(name){';
    echo 'if(name){';
    echo 'if (v==1){';
	echo 'alert("The Delete operation was " + name)';
	echo'}';
//	echo '}';
	echo 'else if (v==2){';
	echo 'alert("The Insert operation was " + name)';
	echo '}else if (v==3){';
	echo 'alert("The Update opertation was " + name)';
	echo '}';
	echo '}';
	echo '}';
	echo '</script>';

	echo '</head>';
	$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
 	

mysql_select_db("srcom", $con);
$name=$_GET['name'];
echo '<body onload="popup(\''.$_GET['str'].'\')">';

echo <<<'EOT'
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
			<h1>SRCOM</h1>
			</div>
			<div id="menu">
				<ul>
					<li class="current_page_item"><a href="home.html" accesskey="1" title="">Homepage</a></li>
				</ul>
			</div>
		</div>
	</div>
	
	<div id="page-wrapper">
		<div id="page">
			<div id="wide-content">
	
			<div>
EOT;

// show a specific tables row 
	echo '<center>';
	 $result = mysql_query("SELECT * FROM $name");
	 if (mysql_num_rows($result)>0){
		 $r = mysql_fetch_array($result,MYSQL_ASSOC);
		 $table="<table border='1'><tr>";
		 $firstLine="<tr>";
		 $c=0;
		 $str="";
		 foreach ($r as $k => $v){
		   $table .="<td>".$k."</td><td></td>";
		   
		  // print $lst[$name][0].$k."</br>";
		   //if( $k==$lst[$name][0]){print "yo"."</br>";}
		   if (in_array($k,$lst[$name])){
		   //if (isset($lst[$name][$k])){
		   //print "yess\n";
			if($c==0){
				$str.="value".(string)($c)."=".$v;
				$c++;
				}
			else{
				$str.="&value".(string)($c)."=".$v;
				$c++;
				}
			}
			
		   $firstLine .="<td>".$v."</td><td></td>";}
		 
		 //$global=$str;
		 //echo '<a href='update.php?name=$name&val='>update</a><br/>'</td>";
	 $firstLine.="<td><a href='update.php?name=$name&$str'>update</a><br/></td>";
	 $firstLine.="<td><a href='delete.php?name=$name&$str'>delete</a><br/></td>";
	 $table.="</tr>".$firstLine."</tr>";
	 
	 while($r = mysql_fetch_array($result,MYSQL_ASSOC)){
	   $table.="<tr>";
	    $c=0;
		$str="";
	   foreach($r as $k => $v){
			
			if (in_array($k,$lst[$name])){
			if($c==0){
				$str.="value".(string)($c)."=".$v;
				$c++;
				}
			else{
				$str.="&value".(string)($c)."=".$v;
				$c++;
				}
			}
	     $table.="<td>".$v."</td><td></td>";
		 }
		 $table.="<td><a href='update.php?name=$name&$str'>update</a><br/></td>";
		 $table.="<td><a href='delete.php?name=$name&$str'>delete</a><br/></td>";
	   $table.="</tr>";
	 }
	  $table .="</table>";
	//print $global."hhoohho";	
	echo $table;
	$lin='<p><a href=input_'.$name.'.html>insert</a><br/></p>';
	print $lin;
	/*$pk=mysql_query('SHOW KEYS FROM '.$name.' WHERE Key_name = \'PRIMARY\';');
	print $pk;
	$ke=mysql_fetch_array($pk);
	extract($ke);
	print $Column_name;*/
	 echo '</center>';
	echo <<<'EOT'
			</div>
		</div>
	</div>
	</div>
</div>
EOT;
}
/*if(isset($_GET[str]))
	
*/
echo '</body>';
echo '</html>';


?>