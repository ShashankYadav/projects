<?php
 require "connector.php";
//inserting data

$name=$_GET['name'];
$bill_no=$_POST['bill_no'];
$cust_name=$_POST['cust_name'];
$cust_no=$_POST['cust_no'];
$issuer_id=$_POST['issuer_id'];
$issue_date=$_POST['issue_date'];
$amt=$_POST['amt'];
$order = "UPDATE bill SET cust_name= '$cust_name' , cust_no= '$cust_no' , issuer_id= '$issuer_id' , issue_date= '$issue_date' , amt= '$amt' where bill_no= '$bill_no';";
 //declare in the order variables
$result = mysql_query($order); //order executes
echo $bill_no.'		'.$cust_name;
if (!$result) {
    die('Invalid query: ' . mysql_error());
}
if($result){
 echo("<br>Update data is succeed");
}
 else{
echo("<br>Update data is fail");
}
$lin='<p><a href=\'show.php?name='.$name.'\'>'.$name.'</a></p>';
print $lin;
?>
