#!/bin/bash
cd /proc/`lsof | grep Flash | tr -s " " | awk ' {print $2} '`/fd
cp `lsof | grep Flash | tr -s " " | awk '{print $4}' |cut -c 1,2` ~/$1
echo -n "Video "
echo -n $1
echo " saved successfully"
