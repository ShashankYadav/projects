<?php
//input.php
mysql_connect("localhost","root","");//database connection
mysql_select_db("srcom");


//inserting data order

$bill_no = $_POST['bill_no'];
$cust_name= $_POST['cust_name'];
$cust_no= $_POST['cust_no'];
$issuer_id= $_POST['issuer_id'];
$issue_date= $_POST['issue_date'];
$amount= $_POST['amount'];
$order = "INSERT INTO bill VALUES('$bill_no','$cust_name','$cust_no','$issuer_id','$issue_date','$amount')";

//declare in the order variable

$result = mysql_query($order);  //order executes

if($result){

    echo("<br>Input data is succeed");

} else{

    echo("<br>Input data is fail");

}

?>
