<?php
 require "connector.php";
//inserting data

$dealer_id=$_POST['dealer_id'];
$dealname=$_POST['dealname'];
$phone=$_POST['phone'];
$deals_in=$_POST['deals_in'];
$order = "INSERT INTO dealer VALUES('$dealer_id','$dealname','$phone','$deals_in')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
