<?php
//input.php 
 mysql_connect("localhost","root","");//database connection 
 mysql_select_db("srcom");

//inserting data

$dealer_id=$_POST['dealer_id'];
$item_no=$_POST['item_no'];
$order = "INSERT INTO supplies VALUES('$dealer_id','$item_no')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}else{
echo("<br>Input data is fail");
?>
