<?php

echo '<html>';
echo '<head>';
    echo ' <link rel="stylesheet" href="ministerial/default.css" type="text/css" /8:33 PM 10/30/2012>';
echo '</head>';
$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
	mysql_select_db("srcom", $con);
	$dealer_no=$_POST['dealer_no'];
	echo '<body>';
	echo <<<'EOT'
	<div id="wrapper">
		<div id="header-wrapper">
			<div id="header">
				<div id="logo">
				<h1>SRCOM</h1>
				</div>
				<div id="menu">
					<ul>
						<li class="current_page_item"><a href="home.php" accesskey="1" title="">Homepage</a></li>
					</ul>
				</div>
			</div>
		</div>
		
		<div id="page-wrapper">
			<div id="page">
				<div id="wide-content">
		
				<div>
EOT;
	$result = mysql_query('SELECT * FROM item i , supplies s where s.dealer_id = '.$dealer_no.' and i.item_no=s.item_no;' );
	echo '<center>';
	if (mysql_num_rows($result)==0)
	{
		echo "<h1>NOT PRESENT IN DATABASE</h1>";
	}
	if (mysql_num_rows($result)>0){
		 $r = mysql_fetch_array($result,MYSQL_ASSOC);
		 $table="<table border='1' cellpadding=\"10\"><tr>";
		 $firstLine="<tr>";
		 foreach ($r as $k => $v){
		   $table .="<td>".$k."</td>";
		   $firstLine .="<td>".$v."</td>";}
	 $table.="</tr>".$firstLine."</tr>";
	 
	 while($r = mysql_fetch_array($result,MYSQL_ASSOC)){
	   $table.="<tr>";
	    $c=0;
		$str="";
	   foreach($r as $k => $v){
	     $table.="<td>".$v."</td>";
		 }
		 $table.="</tr>";
	 }
	  $table .="</table>";
	echo $table;
	 echo '</center>';
	echo <<<'EOT'
			</div>
		</div>
	</div>
	</div>
</div>
EOT;
}
echo '</body>';
echo '</html>';	
?>