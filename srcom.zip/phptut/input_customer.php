<?php
 require "connector.php";
//inserting data

$name=$_GET['name'];
$cust_no=$_POST['cust_no'];
$cust_name=$_POST['cust_name'];
$address=$_POST['address'];
$phone=$_POST['phone'];
//echo $cust_name.'<br/>';
//echo $cust_no.'<br/>';
//echo $address.'<br/>';
//echo $phone.'<br/>';
$order = "INSERT INTO customer VALUES('$cust_no','$cust_name','$address','$phone')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
$lin='<p><a href=\'show.php?name='.$name.'\'>'.$name.'</a></p>';
print $lin;
?>
