<?php
//input.php
mysql_connect("localhost","root","");//database connection
mysql_select_db("srcom");


//inserting data order

$cust_no = $_POST['cust_no'];
$cust_name= $_POST['cust_name'];
$address= $_POST['address'];
$phone= $_POST['phone'];
$order = "INSERT INTO customer VALUES('$cust_no','$cust_name','$address','$phone')";

//declare in the order variable

$result = mysql_query($order);  //order executes

if($result){

    echo("<br>blah blah Input data is succeed");

} else{

    echo("<br>Input data is fail");

}

?>
