<?php
 require "connector.php";
//inserting data

$tid=$_POST['tid'];
$auth_by_ssn=$_POST['auth_by_ssn'];
$to_id=$_POST['to_id'];
$date=$_POST['date'];
$amt=$_POST['amt'];
$desc=$_POST['desc'];
$order = "INSERT INTO payment VALUES('$tid','$auth_by_ssn','$to_id','$date','$amt','$desc')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
