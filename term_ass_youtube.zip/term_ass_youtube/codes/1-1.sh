#!/bin/bash
echo $1 > temp
grep tar temp | wc -l > tem
if(( $(cat tem) == 0))
then
	echo "error: given file is not a tar file"
else
	tar -t -f $(echo $1)
fi
rm temp
rm tem
