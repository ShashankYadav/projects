<?php

	$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
 	

mysql_select_db("srcom", $con);

// show a specific tables row 
	 $result = mysql_query("SELECT * FROM employee");
	 if (mysql_num_rows($result)>0){
		 $r = mysql_fetch_array($result,MYSQL_ASSOC);
		 $table="<table border='1'><tr>";
		 $firstLine="<tr>";
		 foreach ($r as $k => $v){
		   $table .="<td>".$k."</td>";
		   $firstLine .="<td>".$v."</td>";
		 }
	 $table.="</tr>".$firstLine."</tr>";
	 while($r = mysql_fetch_array($result,MYSQL_ASSOC)){
	   $table.="<tr>";
	   foreach($r as $k => $v)
	     $table.="<td>".$v."</td>";
	   $table.="</tr>";
	 }
	  $table .="</table>";
	 echo $table;
}
?>