<?php
$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
	mysql_select_db("srcom", $con);
	$sender=$_GET['name'];
	$val=1;
	echo $sender;	
	$order="UPDATE users SET grp= '$val' WHERE username= '$sender';";
	$result=mysql_query($order);
	if(!$result)
	{
	echo mysql_error();
	}
	header("Location:show.php?name=users");
?>