#!/bin/bash
cd $1
echo Removed files
ls -A | grep "~" > temp
cat temp
rm -rf *~
#cut -d' ' -f2 temp | rev >tem
#cut -c2 tem |rev | cut -c 2-
rm -rf temp
#rm -rf tem
