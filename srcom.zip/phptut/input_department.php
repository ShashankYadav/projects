<?php
 require "connector.php";
//inserting data

$dno=$_POST['dno'];
$dname=$_POST['dname'];
$order = "INSERT INTO department VALUES('$dno','$dname')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
