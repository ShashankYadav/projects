<?php
include 'array.php';
$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
 	

mysql_select_db("srcom", $con);
$name=$_GET['name'];


$len=count($lst[$name]);
$arr=$lst[$name];
//print $len
if($len==1)

{	print "HI\n";
$val1=(int)$_GET['value0'];
	//$query="DELETE FROM ".$name." WHERE ".$arr[0]."=".$val1.";";
	//$result = mysql_query($query);
	//print $result;
	$result=mysql_query('Delete from '.$name.' where '.$arr[0].' = "'.$val1.'";');
	if(!$result)
	{
	print "\n not done \n"; 
	$str="hi";
	}
	else
	{
	$str="bye";
	//print "ho";
	//header("home.html");
	}
}
else if($len==2)
{
$val1=(int)$_GET['value0'];
$val2=$_GET['value1'];
	$result=mysql_query('Delete from '.$name.' where '.$arr[0].' = "'.$val1.'" and '.$arr[1].' = "'.$val2.'";');
	//$result = mysql_query("Delete from '$name' where '$arr'[0]='$val1' and '$arr'[1]='$val2'");
}
else
{
	$val1=(int)$_GET['value0'];
	$val2=$_GET['value1'];
	$val3=$_GET['value2'];
	$result=mysql_query('Delete from '.$name.' where '.$arr[0].' = "'.$val1.'" and '.$arr[1].' = "'.$val2.'" and '.$arr[2].' = "'.$val3.'";');
	//$result = mysql_query("Delete from '$name' where '$arr'[0]='$val1' and '$arr'[1]='$val2' and '$arr'[2]='$val3'");
}
print "DELETE FROM ".$name." WHERE ".$arr[0]."=".$val1;
echo '<br/>';
$lin='<p><a href=\'show.php?name='.$name.'\'>'.$name.'</a></p>';
print $lin;
?>