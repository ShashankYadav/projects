<?php
include 'array.php';
echo '<html>';
echo '<head>';
    echo ' <link rel="stylesheet" href="ministerial/default.css" type="text/css" /8:33 PM 10/30/2012>';
echo '</head>';
	$con = mysql_connect("localhost","root","");
	if (!$con)
  	{
  		die('Could not connect: ' . mysql_error());
  	}
 	

mysql_select_db("srcom", $con);
$name=$_GET['name'];
echo '<body>';
echo <<<'EOT'
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
			<h1>SRCOM</h1>
			</div>
			<div id="menu">
				<ul>
					<li class="current_page_item"><a href="home.html" accesskey="1" title="">Homepage</a></li>
EOT;
					//echo '<li><a href="insert'.$name.'.html" accesskey="2" title="">Insert</a></li>';
					echo '<li><a href="insert.php?name='.$name.'" accesskey="2" title="">Insert</a></li>';
					echo <<<'EOT'
				</ul>
			</div>
		</div>
	</div>
	
	<div id="page-wrapper">
		<div id="page">
			<div id="wide-content">
	
			<div>
EOT;

// show a specific tables row 
	echo '<center>';
	 $result = mysql_query("SELECT * FROM $name");
	 if (mysql_num_rows($result)>0){
		 $r = mysql_fetch_array($result,MYSQL_ASSOC);
		 $table="<table border='1' cellpadding=\"10\"><tr>";
		 $firstLine="<tr>";
		 $c=0;
		 $str="";
		 foreach ($r as $k => $v){
		   $table .="<td>".$k."</td>";
		   
		  // print $lst[$name][0].$k."</br>";
		   //if( $k==$lst[$name][0]){print "yo"."</br>";}
		   if (in_array($k,$lst[$name])){
		   //if (isset($lst[$name][$k])){
		   //print "yess\n";
			if($c==0){
				$str.="value".(string)($c)."=".$v;
				$c++;
				}
			else{
				$str.="&value".(string)($c)."=".$v;
				$c++;
				}
			}
			
		   $firstLine .="<td>".$v."</td>";}
		 
		 //$global=$str;
		 //echo '<a href='update.php?name=$name&val='>update</a><br/>'</td>";
	 $firstLine.="<td><a href='update.php?name=$name&$str'>update</a><br/></td>";
	 $firstLine.="<td><a href='delete.php?name=$name&$str'>delete</a><br/></td>";
	 $table.="</tr>".$firstLine."</tr>";
	 
	 while($r = mysql_fetch_array($result,MYSQL_ASSOC)){
	   $table.="<tr>";
	    $c=0;
		$str="";
	   foreach($r as $k => $v){
			
			if (in_array($k,$lst[$name])){
			if($c==0){
				$str.="value".(string)($c)."=".$v;
				$c++;
				}
			else{
				$str.="&value".(string)($c)."=".$v;
				$c++;
				}
			}
	     $table.="<td>".$v."</td>";
		 }
		 $table.="<td><a href='update.php?name=$name&$str'>update</a><br/></td>";
		 $table.="<td><a href='delete.php?name=$name&$str'>delete</a><br/></td>";
	   $table.="</tr>";
	 }
	  $table .="</table>";
	//print $global."hhoohho";	
	echo $table;
	$lin='<p><a href=insert'.$name.'.html>insert</a><br/></p>';
	//print $lin;
	/*$pk=mysql_query('SHOW KEYS FROM '.$name.' WHERE Key_name = \'PRIMARY\';');
	print $pk;
	$ke=mysql_fetch_array($pk);
	extract($ke);
	print $Column_name;*/
	 echo '</center>';
	echo <<<'EOT'
			</div>
		</div>
	</div>
	</div>
</div>
EOT;
}

echo '</body>';
echo '</html>';

?>