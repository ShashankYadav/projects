#include <iostream>
#include <stdlib.h>
#include <GL/glut.h>
#include "sgl.cpp"
#include <cstdio>

using namespace std;

void display();
void idle();
void keyboard( unsigned char key, int x, int y );
void handleKeypress2(int key, int x, int y);
void handleMouseclick(int button, int state, int x, int y);


int	WIDTH = 700;
int	HEIGHT = 700;
int ww,hh;
float angle=0,movex=0,movey=0;
//int	BLINK = 0;
//int	BLINKNOW = 0;
//int	control_blinking = 0;
void initRendering() {

	glEnable(GL_DEPTH_TEST);        // Enable objects to be drawn ahead/behind one another
	glEnable(GL_COLOR_MATERIAL);    // Enable coloring
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);   // Setting a background color
}
void handleResize(int w, int h) {

//	sglViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//gluPerspective(45.0f, (float)w / (float)h, 0.1f, 200.0f);
	glOrtho ( 0, ww, 0, hh,-3,3 ); // gluOrtho (left,right,bottom,top,near,far) 
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	sglModLoadIdentity();
	sglViewLoadIdentity();
	sglViewport(0, 0, 700, 700);
}
int main(int argc, char **argv) 
{
	//Initializations related to GLUT
	glutInit( &argc, argv );
num=0;
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB ); // Ignore this for now
	ww = glutGet(GLUT_SCREEN_WIDTH);
	hh = glutGet(GLUT_SCREEN_HEIGHT);
	glutInitWindowSize( ww, hh );
	glutCreateWindow( "Assignment 3" );
	initRendering();
	sglModLoadIdentity();
	for(int i=0;i<16;i++)
	{
		if(i==3 || i==7	|| i==11 || i==15)
			modelmatrix[i]=i;
	}
	float tt[4][4];
	for(int i=0;i<16;i++)
		tt[i/4][i%4]=modelmatrix[i];
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4;j++)
			cout<<tt[i][j]<<" ";
		cout<<endl;
	}
	//Telling Glut about which function does what
	glutDisplayFunc( display );
	glutIdleFunc( display );
	glutKeyboardFunc( keyboard );
	glutReshapeFunc(handleResize);
	glutSpecialFunc(handleKeypress2);
	glutMouseFunc(handleMouseclick);
	//glutMouseFunc( mouse );

	//Setting the OpenGL Init State.

	//Following command decides how much part of window to be used for rendering.
	//glViewport( 0, 0, WIDTH, HEIGHT );
//	sglViewport( 0,0, WIDTH, HEIGHT ); //done
	//For Time being assume this is Magic
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	//Following command decides your co-ordinate system
//		glOrtho ( -10, 10, -10, 10,-1,1 ); // gluOrtho2D (left,right,bottom,top) 
//	sglShow(); //ask late -------------------------------------------------------------------------------
	//Your transformation are controlled by the following Matrix
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glutMainLoop();

	return 0;
}

int fl_load=1;
void display( void )
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//sglClear(0,0,0,0);  //ask later-----------------------------------------------

	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
	sglModLoadIdentity();
	sglViewLoadIdentity();
	sglViewport(0, 0, ww, hh);
//	sglLookAt(10,10,10,0,0,0,0,1,0);
	/*for(int i=0;i<16;i++)
	{
		cout<<modelmatrix[i]<<" ";
		if(i+1%4==0)
			cout<<endl;
	}*/
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
		{
			if(i==j)
			{
				project[i][j]=1;
			//	porttrans[i][j]=1;
			}
			else
			{
				project[i][j]=0;
			//	porttrans[i][j]=0;
			}
		}
	sglModTranslate(0,0,-5);
	sglModTranslate(movex,movey,0);
	sglModRotate(angle,0,0,1);
//	sglModScale(0.5,0.5,0.5);
//	sglModRotate(-30,0,0,1);
//	sglViewTranslate(-30,0,0);
//	sglViewRotate(-30,0,0,1);
//	sglProjFrustum(-5,5,-5,5,-1,10);
	sglProjOrtho(-5,5,-5,5,-10,10);
	sglColour(0,1,0);
	if(fl_load==1)
	{
		cout<<"entered\n";
		sglBegin(SGL_TRIANGLES);
		sglVertex(-4,3,0);
		sglVertex(2,5,0);
		sglVertex(3,-5,0);

		sglColour(1,0,0);
		sglBegin(SGL_TRIANGLES);
		sglVertex(-8,-3,0);
		sglVertex(-1,3,0);
		sglVertex(-3,-5,0);
		sglEnd();
		fl_load=0;
	}
	sglShow();
	glFlush();
	glutSwapBuffers();
}

void keyboard( unsigned char key, int x, int y )
{
	if( key==27 )
		exit( 0 );
}
void handleKeypress2(int key, int x, int y) {
	
	if (key == GLUT_KEY_LEFT)
		movex=movex-0.5;
//		sglModTranslate(-0.5,0,0);
	if (key == GLUT_KEY_RIGHT)
		movex=movex+0.5;
//		sglModTranslate(0.5,0,0);
	if (key == GLUT_KEY_UP)
		movey=movey+0.5;
//		sglModTranslate(0,0.5,0);
	if (key == GLUT_KEY_DOWN)
		movey=movey-0.5;
	writefl=1;
//		sglModTranslate(0,-0.5,0);
}

void handleMouseclick(int button, int state, int x, int y) {
	writefl=1;
	if (state == GLUT_DOWN)
	{
		if (button == GLUT_LEFT_BUTTON)
			angle=angle+15;
//			 sglModRotate(15,0,0,1);
		else if (button == GLUT_RIGHT_BUTTON)
			angle=angle+15;
//			 sglModRotate(-15,0,0,1);
	}
}
