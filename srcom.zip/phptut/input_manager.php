<?php
 require "connector.php";
//inserting data

$mgrssn=$_POST['mgrssn'];
$dno=$_POST['dno'];
$order = "INSERT INTO manager VALUES('$mgrssn','$dno')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
