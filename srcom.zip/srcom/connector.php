<?php
$val=mysql_connect("localhost","root","");//database connection 
if (!$val)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("srcom");
?>
