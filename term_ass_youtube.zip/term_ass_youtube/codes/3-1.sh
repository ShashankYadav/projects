#!/bin/bash
cd $1
#echo -n "$PWD"
#echo "/"
#temp=`tree -L 2 ifFsp | tail -1 | cut -d' ' -f3 `
#echo "$temp"
tree -ifFsp 2 $1 | tr -s " " | sort -nk 2| grep -v 4096 | cut -d' ' -f3- | tail -1
