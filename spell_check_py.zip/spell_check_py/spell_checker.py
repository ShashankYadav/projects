import re,collections,sys
def words(text): return re.findall('[a-z]+', text.lower()) 
NWORDS = words(file('dict').read())
alphabet = 'abcdefghijklmnopqrstuvwxyz'

def split(word):
	sp=[]
	for i in range(len(word)+1):
		sp.append((word[:i],word[i:]))
	return sp

def delete(word):
	spl=split(word)
	nu=[]
	for i,j in spl:
		if j:
			nu.append(i+j[1:])
	return nu
def tr(word):
	spl=split(word)
	nu1=[]
	for i,j in spl:
		if len(j)>1:
			nu1.append(i+j[1]+j[0]+j[2:])
	return nu1
def rep(word):
	spl=split(word)
	nu2=[]
	for i,j in spl:
		for k in alphabet:
			if j:
				nu2.append(i+k+j[1:])
	return nu2
def ins(word):
	spl=split(word)
	nu3=[]
	for i,j in spl:
		for k in alphabet:
			nu3.append(i+k+j)
	return nu3
def known(words):
	ans=[]
	for w in words:
		if w in NWORDS:
			ans.append(w)
	return ans
def correct(word):
    #candidates = known([word]) or known(delete(word)) or known(tr(word)) or known(rep(word)) or known(ins(word)) or [word]
    if(len(known([word]))):
   	for i in  known([word]):
		print i
    if(len(known(delete(word)))):
   	for i in  known(delete(word)):
		print i
    if(len(known(rep(word)))):
   	for i in  known(rep(word)):
		print i
    if(len(known(tr(word)))):
   	for i in  known(tr(word)):
		print i
    if(len(known(ins(word)))):
   	for i in  known(ins(word)):
		print i
f=1
for i in NWORDS:
	if i==sys.argv[1]:
		f=0
if f==0:
	print "Word is correctly spelt."
if f==1:
	print "The word is incorrectly spelled.The nearest options are:"
	correct(sys.argv[1])
