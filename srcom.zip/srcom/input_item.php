$name=$_GET['name'];<?php
 require "connector.php";
session_start(); 
// for the admin interface pages
 //remove second condition if interface is to be normal user one!
if(empty($_SESSION['user']) ) 
{
// If they are not, we redirect them to the login page. 
 header("Location: login.php");    
  //print "not valid";
 // Remember that this die statement is absolutely critical.  Without it, 
// people can view your members-only content without logging in. 
die("Redirecting to login.php"); 
}

//inserting data
$name=$_GET['name'];
$item_no=$_POST['item_no'];
$item_name=$_POST['item_name'];
$cost=$_POST['cost'];
$order = "INSERT INTO item VALUES('$item_no','$item_name','$cost')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 $str="Successful";
}
 else{
$str="Unsuccessful";
}
header("Location:show.php?name=$name&str=$str&v=2");
?>
