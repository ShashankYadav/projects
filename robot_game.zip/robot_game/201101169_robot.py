#!/usr/bin/python
import curses
import time
from curses import KEY_LEFT,KEY_RIGHT,KEY_UP,KEY_DOWN,initscr,curs_set,newwin,endwin
import random
from random import randrange, randint
class spikes():
	def __init__(self,x):
		self.wasd=x
	def printsp(self,win,spikes):
		for i in spikes:
			win.addch(i[0],i[1],"^",curses.color_pair(7))
	def chksp(self,spikes):
		for i in spikes:
			if i[0]>=self.y and i[0]<self.y + self.size and i[1]>=self.x and i[1]<self.x + self.size:
				curses.endwin()
				print "OOH YOUR ROBOT CANT WALK NOW,BETTER LUCK NEXT TIME"
				exit(0)
	def spbdrchk(self,spikes,h,w,stx,sty):
		for i in spikes:
			if(i[0]<=sty):
				i[0]=sty+h-3
			if(i[0]>=sty+h):
				i[0]=sty+2
			if(i[1]<=stx):
				i[1]=stx+w-2
			if(i[1]>=stx+w):
				i[1]=stx+2
	def spmov(self,spikes):
		for i in range(len(spikes)):
			if spikes[i][2]==0:
				spikes[i][1]=spikes[i][1]-1
			if spikes[i][2]==1:
				spikes[i][1]=spikes[i][1]+1
			if spikes[i][2]==2:
				spikes[i][0]=spikes[i][0]-1
			if spikes[i][2]==3:
				spikes[i][0]=spikes[i][0]+1
		return spikes
class defuses:
	def __init__(self,x):
		self.wasd1=x
	def printdef(self,win,defuses):
		for i in defuses:
			win.addch(i[0],i[1],'D',curses.color_pair(5))
	def chkdef(self,defuses):
		for i in defuses:
			if i[0] >= self.y and i[0]<self.y+self.size and i[1] >= self.x and i[1]<self.x + self.size:
				defuses.remove(i)
				self.score=self.score+1
		return defuses
class bomb:
	def __init__(self):
		self.wasd2=0
	def printb(self,win,bombpos):
		win.addch(bombpos[0], bombpos[1],'B',curses.color_pair(4))
	def chkbmb(self,bps):
		if bps[0]>=self.y and bps[0]<self.y+self.size and bps[1]>=self.x and bps[1]<self.x+self.size:
			#curses.endwin()
			if self.score==5:
				#print "CONGRATULATIONS YOU HAVE WON"
				return 1
			else:
				msg=curses.newwin(3,25,1,1)
				msg.border('|','|','-','-','+','+','+','+')
				curses.curs_set(0)
				curses.noecho()
				msg.addstr(1,2,"ROBOT BLOWN,TRY AGAIN",curses.color_pair(5))
				ex=msg.getch()
				msg.clear()
				curses.endwin()
				#time.sleep(1)
				#curses.initscr()
				curses.endwin()
				#curses.endwin()
				#print "BETTER LUCK NEXT TIME"
				exit(0)
	
class robot(spikes,defuses,bomb):

	def __init__(self,x,y,size):
		self.x=x
		self.y=y
		self.size=size
		self.score=0
		self.rob=[["X"],["OO","XX"],["_O_ ","^_^","/ \\"],["_00_","/oo\\","X/\\X","/  \\"],["\\___/","|^_^|","/o o\\","X O X","_/ \\_"]]
		spikes.__init__(self,0)
		defuses.__init__(self,0)
		bomb.__init__(self)

	def printrob(self,win):
		for i in range(self.size):
			win.addstr(self.y+i,self.x,self.rob[size-1][i],curses.color_pair(6))
	def prallkill(self,win,pos):
		win.addch(pos[0],pos[1],'@',curses.color_pair(6))

#	def printb(self,win,bombpos):
#		win.addch(bombpos[0], bombpos[1],'B',curses.color_pair(4))

	def challkill(self,pos):
		if pos[0]>=self.y and pos[0]<self.y+self.size and pos[1]>=self.x and pos[1]<self.x+self.size:
			return 1
		else:
			return 0
	def chkbdr(self,h,w,stx,sty):
		if self.x<=stx or self.y<=sty or self.y+self.size>=sty+h or self.x+self.size>=stx+w:
			msg=curses.newwin(3,30,1,1)
			msg.border('|','|','-','-','+','+','+','+')
			curses.curs_set(0)
			curses.noecho()
			msg.addstr(1,2,"DRIVE CAREFULLY NEXT TIME",curses.color_pair(5))
			ex=msg.getch()
			msg.clear()
			curses.endwin()
			curses.endwin()
			exit(0)
	
	def pause(self,win):
		key=-1
		while (1):
			key=win.getch()
			if key == ord('p'):
				break
			elif key==27:
			 	curses.endwin()
			 	print "BYE BYE LOSER"
			 	exit(0)
			else:
			 	continue

			
	def getx(self):
	 	return self.x
	def gety(self):
		return self.y
	def getsize(self):
	 	return self.size
	def getscore(self):
	 	return self.score
	def decx(self):
	  	self.x=self.x-1
	def incx(self):
	  	self.x=self.x+1
	def incy(self):
	  	self.y=self.y+1
	def decy(self):
	  	self.y=self.y-1
print "Welcome to the robot game,Please choose your battlefield size :"
print "please enter the height(should be less than 30 and greater than 10) : ",
try:
	h=int(raw_input(""))
except :
	h=30
if(h>30 or h<10):
	h=30
#print h
print "please enter the width(should be less than 100 and greater than 20) : ",
try:
	w=int(raw_input(""))
except:
	w=100
if(w>100 or w<20):
	w=100
#print w
print "please enter the robot size(should be less than 5 and greater than 1) : ",
try:
	size=int(raw_input(""))
except:
	size=3
if(size>5 or size<2):
	size=3
#print size

def g(i,j,z):
	global size
	global h
	global w
	key=KEY_DOWN
	cont=key
	score=0
	x=2
	y=2

	game=robot(x,y,size)
	#sp=spike()
	defuses=[]
	defuse=[]
	de=5
	defuses.extend([n for n in [[randint(1,h-2), randint(1,w-2),randint(0,3)] for x in range(100)] if (n[0]<y or n[0]>y+size) and (n[1]<x or n[1]>x+size)])
	bombpos=defuses[len(defuses)-1]
	sp=defuses[40:]
	spikes=[]
	for zx in sp:
		if((zx[0]<y+size+3 and zx[0]>y-1) or (zx[1]>x+2 and zx[1]<x+size-2)):
			continue
		else:
		 	spikes.append(zx)
		if(len(spikes)>j-40):
			break
	#spikes=defuses[40:j]
	allkiller=defuses[len(defuses)-4]
	for ax in range(10):
		if defuses[ax][0]==defuses[ax+1][0] and defuses[ax][1]==defuses[ax+1][1]:
			continue
		else:
			if(len(defuse)<5):
				defuse.append(defuses[ax])
			else:
				break
			
	curses.initscr()
	curses.start_color()
	curses.init_pair(3,curses.COLOR_WHITE,curses.COLOR_BLACK)
	curses.init_pair(4,curses.COLOR_RED,curses.COLOR_BLACK)
	curses.init_pair(5,curses.COLOR_CYAN,curses.COLOR_BLACK)
	curses.init_pair(6,curses.COLOR_GREEN,curses.COLOR_BLACK)
	curses.init_pair(7,curses.COLOR_YELLOW,curses.COLOR_BLACK)
	curses.curs_set(0)
	win=curses.newwin(h,w,0,0)
	win.keypad(1)
	win.nodelay(1)
	win.border('|','|','-','-','+','+','+','+')
	curses.noecho()	
	cntr=0
	done=0
	rstcntr=0
	stopcntr=200
	stfl=0
	while key!=27:
		rstcntr=rstcntr+1
		cntr=cntr+1
		win.clear()
		if(stfl==1):
			stopcntr+=1
		if(cntr>100 and cntr<100+i and done!=1):
			ret=game.challkill(allkiller)
			if ret==1:
				spikes=[]
				done=1
				stopcntr=0
				stfl=1
			game.prallkill(win,allkiller)
		if(z>0 and rstcntr>60 and stopcntr>100):
			defuse1=[]
			rstcntr=0
			defuse1.extend([n for n in [[randint(1,h-2), randint(1,w-2),randint(0,3)] for x in range(100)] if (n[0]<y or n[0]>y+size) and (n[1]<x or n[1]>x+size)])
			#bombpos=defuses[len(defuses)-1]
			spikes=defuse1[40:j]
			#allkiller=defuses[len(defuses)-4]
		win.border('|','|','-','-','+','+','+','+')
		x=game.getx()
		y=game.gety()
		size=game.getsize()	
		game.chkbdr(h,w,0,0)
		game.chksp(spikes)
		game.spbdrchk(spikes,h,w,0,0)
		game.printrob(win)
		defuse=game.chkdef(defuse)
		x=0
		x=game.chkbmb(bombpos)
		if x==1:
#curses.flash()
			msg=curses.newwin(3,24,1,1)
			msg.border('|','|','-','-','+','+','+','+')
			curses.curs_set(0)
			curses.noecho()
			msg.addstr(1,2,"want to continue(y/n)",curses.color_pair(5))
			ex=msg.getch()
			msg.clear()
			msg.erase()
			curses.endwin()
			#time.sleep(1)
			#curses.initscr()
			curses.endwin()
			if(ex==ord('n') or ex==ord('N')):
				#curses.endwin()
				exit(0)
			break
		game.printdef(win,defuse)
		game.printsp(win,spikes)
		game.printb(win, bombpos)
		win.addstr(0,2, "SCORE : " + str(game.getscore()))
		win.timeout(i)
		game.spmov(spikes)
		key=win.getch()
		if key == 27:
			curses.endwin()
			print "BYE BYE LOSER"
			exit(0)
		if key== -1:
			key=cont
		if key == ord('p'):
			game.pause(win)
		if key==KEY_LEFT:
			game.decx()
			cont=key
		elif key==KEY_RIGHT:
			game.incx()
			cont=key
		elif key==KEY_UP:
			game.decy()
			cont=key
		elif key==KEY_DOWN:
			game.incy()
			cont=key
if __name__=="__main__":
	i=160
	global j
	global k
	K=0
	f=0
	j=40
	z=0
	while(i>=40):
		g(i,j,z)
		i=i-20
		j=j+2
		z=z+1
		#if(i==30):
#			break
if f==0:
	print "YOU ARE THE GAMER OF GAMERS"
exit(0)
