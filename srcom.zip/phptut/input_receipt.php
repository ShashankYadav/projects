<?php
 require "connector.php";
//inserting data

$tid=$_POST['tid'];
$from_id=$_POST['from_id'];
$given_to_ssn=$_POST['given_to_ssn'];
$date=$_POST['date'];
$order = "INSERT INTO receipt VALUES('$tid','$from_id','$given_to_ssn','$date')";
 //declare in the order variables
$result = mysql_query($order); //order executes
if($result){
 echo("<br>Input data is succeed");
}
 else{
echo("<br>Input data is fail");
}
?>
