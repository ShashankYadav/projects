<?php

// for the admin interface pages
//remove second condition if interface is to be normal user one!
	session_start(); 
if(empty($_SESSION['user']) ) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: login.php"); 
         //print "not valid";
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to login.php"); 
    } 
	

//confirmation done regarding the interface of stuff
echo '<html>';
echo '<head>';
echo '<link rel="stylesheet" href="ministerial/default.css" type="text/css" /8:33 PM 10/30/2012>';
echo '<title>customer input</title>
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
			<h1>SRCOM</h1>
			</div>
		<div id="menu">
				<ul>
					<li class="current_page_item"><a href="special.html" accesskey="1" title="">SPECIAL QUERIES</a></li>
					<li><a href="logout.php" accesskey="2" title="">LOGOUT</a></li>';
					if($_SESSION['user']['grp']==1) print "<li><a href='show.php?name=users'>USERS</a></li>";
					
		echo'		</ul>
			</div>
		</div>	
		
	</div>
	<div id="page-wrapper">
		<div id="page">
			<div id="wide-content">
				<div>';
	/*foreach ($_SESSION['user'] as $j=>$i)
	{
		print $j + " --> " + $i+"\n";
	}*/
	//print_r(array_keys($_SESSION['user']));
	//print $_SESSION['group'];
//	print	$_SESSION['user']['group'];
			/*print "	<a href='show.php?name=bill'>Bill</a><br/>" ;
			print "	<a href='show.php?name=customer'>Customer</a><br/>";
			print"	<a href='show.php?name=dealer'>Dealer</a><br/>";
			print"	<a href='show.php?name=department'>Department</a><br/>";
			print"	<a href='show.php?name=dependent'>Dependent</a><br/>";
			print"	<a href='show.php?name=employee'>Employee</a><br/>";
			print"	<a href='show.php?name=item'>Item</a><br/>";
			print"	<a href='show.php?name=manager'>Manager</a><br/>";
			print"	<a href='show.php?name=payment'>payment</a><br/>";
			print"	<a href='show.php?name=preorder'>Preorder</a><br/>";
			print"	<a href='show.php?name=receipt'>Receipt</a><br/>";
			print"	<a href='show.php?name=receives_from'>Receives from</a><br/>";
			print"	<a href='show.php?name=sells'>Sells</a><br/>";
		print"		<a href='show.php?name=stock'>Stock</a><br/>";
		print"		<a href='show.php?name=supplies'>Supplies</a><br/>";
		print"		<a href='show.php?name=worker'>Worker</a><br/>";*/
		echo '<center>
				<table border=\'0\' cellpadding="10"><tr></tr>
				<tr>';
		print"		<td><a href='show.php?name=bill'>BILL</a></td>";
		print"		<td><a href='show.php?name=customer'>CUSTOMER</a></td>";
	if($_SESSION['user']['grp']==1)	print"		<td><a href='show.php?name=dealer'>DEALER</a></td>";
	if($_SESSION['user']['grp']==1)	print"		<td><a href='show.php?name=department'>DEPARTMENT</a></td>";
		print"		</tr>";
		print"		<tr>";
		if($_SESSION['user']['grp']==1)	print"		<td><a href='show.php?name=dependent'>DEPENDENT</a></td>";
		if($_SESSION['user']['grp']==1)	print"		<td><a href='show.php?name=employee'>EMPLOYEE</a></td>";
		 print"		<td><a href='show.php?name=item'>ITEM</a></td>";
	if($_SESSION['user']['grp']==1) 	print"		<td><a href='show.php?name=manager'>MANAGER</a></td>";
		print"		</tr>";
		print"		<tr>";
	if($_SESSION['user']['grp']==1)	print"		<td><a href='show.php?name=payment'>PAYMENT</a></td>";
		 print"		<td><a href='show.php?name=preorder'>PREORDER</a></td>";
	if($_SESSION['user']['grp']==1) 	print"		<td><a href='show.php?name=receipt'>RECEIPT</a></td>";
	if($_SESSION['user']['grp']==1) 	print"		<td><a href='show.php?name=receives_from'>RECEIVES FROM</a></td>";
		print"		</tr>";
		print"		<tr>";
		print"		<td><a href='show.php?name=sells'>SELLS</a></td>";
		print"		<td><a href='show.php?name=stock'>STOCK</a></td>";
		if($_SESSION['user']['grp']==1) print"		<td><a href='show.php?name=supplies'>SUPPLIES</a></td>";
	if($_SESSION['user']['grp']==1) 	print"		<td><a href='show.php?name=worker'>WORKER</a></td>";
	print"		</tr>";
	
		echo'		
				</table>
				</center>';
		
		echo'		</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>';
?>