#!/bin/bash
who | grep -v tty | cut -d' ' -f1
